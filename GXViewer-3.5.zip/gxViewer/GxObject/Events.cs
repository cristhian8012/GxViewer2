using System;
using System.Collections.Generic;
using System.Text;

namespace gxViewer.GxObject
{
    public class Events
    {
        private string _source;

        public string Source
        {
            get { return _source; }
            set { _source = value; }
        }
    }
}
