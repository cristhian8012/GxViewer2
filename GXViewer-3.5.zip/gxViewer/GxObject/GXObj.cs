using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;


namespace gxViewer.GxObject
{
    [DefaultPropertyAttribute("Info")]
    public class GXObj
    {
        private GxObject.Documentation _Documentation;
        private GxObject.Help _Help;
        private GxObject.ObjInfo _ObjInfo;
        private GxObject.Info _Info;

        private GxObject.Variable[] _variables;
        private GxObject.GXAtt[] _GXAtt;

        private Dictionary<string, GxObject.Property> _Props = new Dictionary<string, Property>();
        private Dictionary<string, GxObject.Variable> _Vars = new Dictionary<string, Variable>();
        private Dictionary<string, GxObject.GXAtt> _GxAttrs = new Dictionary<string, GXAtt>();


        private GxObject.Group[] _groups;
        private GxObject.Folder[] _folders;

        private string _Rules;
        private string _Subroutines;
        private string _LastUpdate;
        private string _Source;
        private string _Conditions;

        private KMW _KMW;
        private string _XMLObj;

        [Category("Dise�o")]
        [Description("Tipo de Objeto")]
        public virtual string Tipo
        {
            get { return this.ToString(); }
        }


        #region readonly Property by ProperyGrid
        [Category("Dise�o")]
        public string Name
        {   
            get { return _Info.Name;  }
        }
        [Category("Dise�o")]
        public string Description
        {
            get { return _Info.Description; }
        }
        [Category("Dise�o")]
        public string Folder
        {
            get { return  _Info.Folder; }
        }


        [Category("Modelo")]
        public string Modelo
        {
            get { return _KMW.Path; }
        }
        [Category("Modelo")]
        public string Version
        {
            get { return String.Format("{0}.{1}.{2}", _KMW.MajorVersion,_KMW.MinorVersion, _KMW.MaxGxBuildSaved )  ; }
        }

        #endregion


        public string GetVariablesInLayout()
        {
            return "".ToLower();
        }

        public string GetTotalSource()
        {
            StringBuilder _strb = new StringBuilder();
            _strb.AppendLine("// RULES--");
            _strb.AppendLine(this.Rules);

            _strb.AppendLine("// SOURCE--");
            _strb.AppendLine(this.Source);

            _strb.AppendLine("// SUBROUTINES--");
            _strb.AppendLine(this.Subroutines);

            _strb.AppendLine("// CONDITIONS--");
            _strb.AppendLine(this.Conditions);

            return _strb.ToString().ToLower();
        }

        public Variable getVarByName( string varName)
        {
            try
            {
                Variable _var = _Vars[varName];
                return _var;
            }
            catch (Exception)
            {
                return null;
            }
        }

        [BrowsableAttribute(false)]
        public GxObject.Documentation Documentation
        {
            get { return _Documentation; }
            set { _Documentation=value; }
        }


        [BrowsableAttribute(false)]
        public GxObject.Info Info
        {
            get { return _Info; }
            set { _Info = value; }
        }

        [BrowsableAttribute(false)]
        public GxObject.Help Help
        {
            get { return _Help; }
            set { _Help = value; }
        }
        [BrowsableAttribute(false)]
        public GxObject.Variable[] Variables
        {
            get { return _variables; }
            set { _variables = value; }
        }

        [BrowsableAttribute(false)]
        public GxObject.GXAtt[] GXAtts
        {
            get { return _GXAtt; }
            set { _GXAtt = value; }
        }

        [BrowsableAttribute(false)]
        public Dictionary<string, GxObject.Property> Propiedades
        {
            get { return _Props; }
            set { _Props = value; }
        }

        [BrowsableAttribute(false)]
        public Dictionary<string, GxObject.Variable> GXVariables
        {
            get { return _Vars; }
            set { _Vars = value; }
        }

        [BrowsableAttribute(false)]
        public Dictionary<string, GxObject.GXAtt> GXAtributos
        {
            get { return _GxAttrs; }
            set { _GxAttrs = value; }
        }


        [BrowsableAttribute(false)]
        public GxObject.Group[] Groups
        {
            get { return _groups; }
            set { _groups = value; }
        }

        [BrowsableAttribute(false)]
        public GxObject.Folder[] Folders
        {
            get { return _folders; }
            set { _folders = value; }
        }

        [BrowsableAttribute(false)]
        public GxObject.ObjInfo ObjInfo
        {
            get { return _ObjInfo; }
            set { _ObjInfo = value; }
        }
        public string LastUpdate
        {
            get { return _LastUpdate; }
            set { _LastUpdate = value; }
        }

        [BrowsableAttribute(false)]
        public string Rules
        {
            get { return _Rules; }
            set { _Rules = value; }
        }
        [BrowsableAttribute(false)]
        public string Subroutines
        {
            get { return _Subroutines; }
            set { _Subroutines = value; }
        }

        [BrowsableAttribute(false)]
        public string Source
        {
            get { return _Source; }
            set { _Source = value; }
        }

        [BrowsableAttribute(false)]
        public string Conditions
        {
            get { return _Conditions; }
            set { _Conditions  = value; }
        }

        [BrowsableAttribute(false)]
        public KMW KMW
        {
            get { return _KMW; }
            set { _KMW = value; }
        }

        [BrowsableAttribute(false)]
        public string XMLObj
        {
            get { return _XMLObj; }
            set { _XMLObj = value; }
        }

       


    }
}
