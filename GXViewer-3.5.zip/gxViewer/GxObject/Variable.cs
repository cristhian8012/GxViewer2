using System;
using System.Collections.Generic;
using System.Text;

namespace gxViewer.GxObject
{
    public class Variable
    {
        private string _id;
        private string _Name;
        private string _Title;
        private string _Type = "numeric";
        private int _Length;
        private int _Decimals;
        private string _Picture;
        private string _BasedOn;
        private int _Rows;
        private int _Columns;
        private Property _property;

        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string Title
        {
            get { return _Title; }
            set { _Title= value; }
        }
        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        public int Length
        {
            get 
            {
                if (this._Length <= 0 && this._Type == "numeric")
                {
                    if (!String.IsNullOrEmpty(_Picture))
                    {
                        this._Length = this._Picture.Length;
                    }
                }
                else
                {
                    if (this._Length <= 0 && this._Type.ToLower() == "character")
                    {
                        this._Length = 10;
                    }
                 }

                return _Length; 
            }
            set { _Length = value; }
        }
        public int Decimals
        {
            get { return _Decimals; }
            set { _Decimals = value; }
        }

        public int Rows
        {
            get { return _Rows; }
            set { _Rows = value; }
        }
        public int Columns
        {
            get { return _Columns; }
            set { _Columns = value; }
        }

        public Property Property
        {
            get { return _property; }
            set { _property = value; }
        }

        public string BasedOn
        {
            get { return _BasedOn; }
            set { _BasedOn = value; }
        }

        public string Picture
        {
            get { return _Picture; }
            set { _Picture = value; }
        }

        public int Decimales 
        {
            get
            {
                int _x = 0;
                if (this._Decimals <= 0 && this._Type=="numeric")
                {
                    if (!String.IsNullOrEmpty(_Picture))
                    {
                        int _index =  this._Picture.IndexOf( ".");
                        if (_index > 0)
                        {
                            string _strDecs = this._Picture.Substring(_index + 1);
                            _x = _strDecs.Length;
                        }
                    }
                }
                else
                {
                    _x = this._Decimals;
                }


                return _x;
            }
        }

        public string Name2
        {
            get { return String.Format("&{0}", this._Name.ToLower()); }
        }


    }
}
