﻿namespace gxViewer
{
    partial class GxEditor
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GxEditor));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.paneltop = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tsBarraOpciones = new System.Windows.Forms.ToolStrip();
            this.tssbOpciones = new System.Windows.Forms.ToolStripSplitButton();
            this.verXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.verificarVariablesNoUtilizadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbValidadorGX = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.buscarObjetoEnElModeloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbClose = new System.Windows.Forms.ToolStripButton();
            this.lbldescrip = new System.Windows.Forms.Label();
            this.lblTipoObjeto = new System.Windows.Forms.Label();
            this.lblNombreObjeto = new System.Windows.Forms.LinkLabel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbObjeto = new System.Windows.Forms.TabControl();
            this.tabStructure = new System.Windows.Forms.TabPage();
            this.wbStructure = new System.Windows.Forms.WebBrowser();
            this.tabLayout = new System.Windows.Forms.TabPage();
            this.webDesign = new System.Windows.Forms.WebBrowser();
            this.tabRules = new System.Windows.Forms.TabPage();
            this.txtRules = new FastColoredTextBoxNS.FastColoredTextBox();
            this.cmsOpcionesTXT = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.colapsarSeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leccionToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.colapsarTodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.asigmarMarcadorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desAsignarMarcadorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.buscarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reemplazarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irALineaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.seleccionarTodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabCode = new System.Windows.Forms.TabPage();
            this.txtCode = new FastColoredTextBoxNS.FastColoredTextBox();
            this.tabConditions = new System.Windows.Forms.TabPage();
            this.txtConditions = new FastColoredTextBoxNS.FastColoredTextBox();
            this.tabHelp = new System.Windows.Forms.TabPage();
            this.wbhelp = new System.Windows.Forms.WebBrowser();
            this.tabDocument = new System.Windows.Forms.TabPage();
            this.wbdoc = new System.Windows.Forms.WebBrowser();
            this.tabvariables = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panelvariables = new System.Windows.Forms.Panel();
            this.groupBoxVars = new System.Windows.Forms.GroupBox();
            this.dgvVars = new System.Windows.Forms.DataGridView();
            this.cid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctamanio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cdecimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colpicvar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtFindVars = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBoxAttrs = new System.Windows.Forms.GroupBox();
            this.dgvAttrs = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctitulo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtFindAttr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabProp = new System.Windows.Forms.TabPage();
            this.paneltop.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tsBarraOpciones.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tbObjeto.SuspendLayout();
            this.tabStructure.SuspendLayout();
            this.tabLayout.SuspendLayout();
            this.tabRules.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRules)).BeginInit();
            this.cmsOpcionesTXT.SuspendLayout();
            this.tabCode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCode)).BeginInit();
            this.tabConditions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtConditions)).BeginInit();
            this.tabHelp.SuspendLayout();
            this.tabDocument.SuspendLayout();
            this.tabvariables.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panelvariables.SuspendLayout();
            this.groupBoxVars.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVars)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBoxAttrs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttrs)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // paneltop
            // 
            this.paneltop.Controls.Add(this.panel5);
            this.paneltop.Controls.Add(this.lbldescrip);
            this.paneltop.Controls.Add(this.lblTipoObjeto);
            this.paneltop.Controls.Add(this.lblNombreObjeto);
            this.paneltop.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneltop.Location = new System.Drawing.Point(0, 0);
            this.paneltop.Name = "paneltop";
            this.paneltop.Size = new System.Drawing.Size(814, 37);
            this.paneltop.TabIndex = 5;
            this.paneltop.Paint += new System.Windows.Forms.PaintEventHandler(this.paneltop_Paint);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tsBarraOpciones);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(621, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(193, 37);
            this.panel5.TabIndex = 3;
            // 
            // tsBarraOpciones
            // 
            this.tsBarraOpciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tsBarraOpciones.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tsBarraOpciones.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.tsBarraOpciones.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssbOpciones,
            this.toolStripSeparator1,
            this.tsbClose});
            this.tsBarraOpciones.Location = new System.Drawing.Point(0, 0);
            this.tsBarraOpciones.Name = "tsBarraOpciones";
            this.tsBarraOpciones.Size = new System.Drawing.Size(193, 37);
            this.tsBarraOpciones.TabIndex = 6;
            this.tsBarraOpciones.Text = "Opciones";
            // 
            // tssbOpciones
            // 
            this.tssbOpciones.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verXMLToolStripMenuItem,
            this.toolStripMenuItem1,
            this.verificarVariablesNoUtilizadasToolStripMenuItem,
            this.toolStripMenuItem2,
            this.tsbValidadorGX,
            this.toolStripMenuItem3,
            this.buscarObjetoEnElModeloToolStripMenuItem});
            this.tssbOpciones.Image = global::gxViewer.Properties.Resources.editar_on;
            this.tssbOpciones.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tssbOpciones.Name = "tssbOpciones";
            this.tssbOpciones.Size = new System.Drawing.Size(97, 34);
            this.tssbOpciones.Text = "Opciones";
            // 
            // verXMLToolStripMenuItem
            // 
            this.verXMLToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verXMLToolStripMenuItem.Name = "verXMLToolStripMenuItem";
            this.verXMLToolStripMenuItem.Size = new System.Drawing.Size(239, 24);
            this.verXMLToolStripMenuItem.Text = "Ver XML";
            this.verXMLToolStripMenuItem.Click += new System.EventHandler(this.verXMLToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(236, 6);
            // 
            // verificarVariablesNoUtilizadasToolStripMenuItem
            // 
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Enabled = false;
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.verificarVariablesNoUtilizadasToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Name = "verificarVariablesNoUtilizadasToolStripMenuItem";
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Size = new System.Drawing.Size(239, 24);
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Text = "Eliminar variables No Utilizadas";
            this.verificarVariablesNoUtilizadasToolStripMenuItem.Click += new System.EventHandler(this.verificarVariablesNoUtilizadasToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(236, 6);
            // 
            // tsbValidadorGX
            // 
            this.tsbValidadorGX.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.tsbValidadorGX.ForeColor = System.Drawing.Color.Blue;
            this.tsbValidadorGX.Name = "tsbValidadorGX";
            this.tsbValidadorGX.Size = new System.Drawing.Size(239, 24);
            this.tsbValidadorGX.Text = "Validador GX";
            this.tsbValidadorGX.Click += new System.EventHandler(this.tsbValidadorGX_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(236, 6);
            // 
            // buscarObjetoEnElModeloToolStripMenuItem
            // 
            this.buscarObjetoEnElModeloToolStripMenuItem.Enabled = false;
            this.buscarObjetoEnElModeloToolStripMenuItem.Name = "buscarObjetoEnElModeloToolStripMenuItem";
            this.buscarObjetoEnElModeloToolStripMenuItem.Size = new System.Drawing.Size(239, 24);
            this.buscarObjetoEnElModeloToolStripMenuItem.Text = "Buscar Objeto en el Modelo";
            this.buscarObjetoEnElModeloToolStripMenuItem.Click += new System.EventHandler(this.buscarObjetoEnElModeloToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // tsbClose
            // 
            this.tsbClose.Image = global::gxViewer.Properties.Resources.cerrar_on;
            this.tsbClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbClose.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbClose.Name = "tsbClose";
            this.tsbClose.Size = new System.Drawing.Size(67, 34);
            this.tsbClose.Text = "Cerrar";
            this.tsbClose.Click += new System.EventHandler(this.tsbClose_Click);
            // 
            // lbldescrip
            // 
            this.lbldescrip.AutoSize = true;
            this.lbldescrip.Location = new System.Drawing.Point(248, 12);
            this.lbldescrip.Name = "lbldescrip";
            this.lbldescrip.Size = new System.Drawing.Size(0, 13);
            this.lbldescrip.TabIndex = 2;
            // 
            // lblTipoObjeto
            // 
            this.lblTipoObjeto.AutoSize = true;
            this.lblTipoObjeto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoObjeto.ForeColor = System.Drawing.Color.Red;
            this.lblTipoObjeto.Location = new System.Drawing.Point(5, 10);
            this.lblTipoObjeto.Name = "lblTipoObjeto";
            this.lblTipoObjeto.Size = new System.Drawing.Size(102, 16);
            this.lblTipoObjeto.TabIndex = 1;
            this.lblTipoObjeto.Text = "Tipo Objeto : ";
            // 
            // lblNombreObjeto
            // 
            this.lblNombreObjeto.AutoSize = true;
            this.lblNombreObjeto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreObjeto.Location = new System.Drawing.Point(113, 10);
            this.lblNombreObjeto.Name = "lblNombreObjeto";
            this.lblNombreObjeto.Size = new System.Drawing.Size(68, 16);
            this.lblNombreObjeto.TabIndex = 0;
            this.lblNombreObjeto.TabStop = true;
            this.lblNombreObjeto.Text = "OBJETO";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "wform.png");
            this.imageList1.Images.SetKeyName(1, "wrules.png");
            this.imageList1.Images.SetKeyName(2, "wevents.png");
            this.imageList1.Images.SetKeyName(3, "wconditions.png");
            this.imageList1.Images.SetKeyName(4, "whelp.png");
            this.imageList1.Images.SetKeyName(5, "wdocs.png");
            this.imageList1.Images.SetKeyName(6, "variables.png");
            this.imageList1.Images.SetKeyName(7, "structure.png");
            this.imageList1.Images.SetKeyName(8, "properties.png");
            this.imageList1.Images.SetKeyName(9, "Close.gif");
            this.imageList1.Images.SetKeyName(10, "key");
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbObjeto);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(814, 407);
            this.panel1.TabIndex = 6;
            // 
            // tbObjeto
            // 
            this.tbObjeto.Controls.Add(this.tabStructure);
            this.tbObjeto.Controls.Add(this.tabLayout);
            this.tbObjeto.Controls.Add(this.tabRules);
            this.tbObjeto.Controls.Add(this.tabCode);
            this.tbObjeto.Controls.Add(this.tabConditions);
            this.tbObjeto.Controls.Add(this.tabHelp);
            this.tbObjeto.Controls.Add(this.tabDocument);
            this.tbObjeto.Controls.Add(this.tabvariables);
            this.tbObjeto.Controls.Add(this.tabProp);
            this.tbObjeto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbObjeto.ImageList = this.imageList1;
            this.tbObjeto.Location = new System.Drawing.Point(0, 0);
            this.tbObjeto.Multiline = true;
            this.tbObjeto.Name = "tbObjeto";
            this.tbObjeto.SelectedIndex = 0;
            this.tbObjeto.Size = new System.Drawing.Size(814, 407);
            this.tbObjeto.TabIndex = 5;
            // 
            // tabStructure
            // 
            this.tabStructure.Controls.Add(this.wbStructure);
            this.tabStructure.ImageIndex = 7;
            this.tabStructure.Location = new System.Drawing.Point(4, 23);
            this.tabStructure.Name = "tabStructure";
            this.tabStructure.Size = new System.Drawing.Size(806, 380);
            this.tabStructure.TabIndex = 8;
            this.tabStructure.Text = "Estructura";
            this.tabStructure.UseVisualStyleBackColor = true;
            // 
            // wbStructure
            // 
            this.wbStructure.AllowNavigation = false;
            this.wbStructure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbStructure.IsWebBrowserContextMenuEnabled = false;
            this.wbStructure.Location = new System.Drawing.Point(0, 0);
            this.wbStructure.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbStructure.Name = "wbStructure";
            this.wbStructure.Size = new System.Drawing.Size(806, 380);
            this.wbStructure.TabIndex = 1;
            // 
            // tabLayout
            // 
            this.tabLayout.Controls.Add(this.webDesign);
            this.tabLayout.ImageIndex = 0;
            this.tabLayout.Location = new System.Drawing.Point(4, 23);
            this.tabLayout.Name = "tabLayout";
            this.tabLayout.Size = new System.Drawing.Size(806, 380);
            this.tabLayout.TabIndex = 7;
            this.tabLayout.Text = "Diseño";
            this.tabLayout.UseVisualStyleBackColor = true;
            // 
            // webDesign
            // 
            this.webDesign.AllowNavigation = false;
            this.webDesign.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webDesign.IsWebBrowserContextMenuEnabled = false;
            this.webDesign.Location = new System.Drawing.Point(0, 0);
            this.webDesign.MinimumSize = new System.Drawing.Size(20, 20);
            this.webDesign.Name = "webDesign";
            this.webDesign.Size = new System.Drawing.Size(806, 380);
            this.webDesign.TabIndex = 2;
            // 
            // tabRules
            // 
            this.tabRules.Controls.Add(this.txtRules);
            this.tabRules.ImageIndex = 1;
            this.tabRules.Location = new System.Drawing.Point(4, 23);
            this.tabRules.Name = "tabRules";
            this.tabRules.Padding = new System.Windows.Forms.Padding(3);
            this.tabRules.Size = new System.Drawing.Size(806, 380);
            this.tabRules.TabIndex = 0;
            this.tabRules.Text = "Reglas";
            this.tabRules.UseVisualStyleBackColor = true;
            // 
            // txtRules
            // 
            this.txtRules.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.txtRules.AutoIndentCharsPatterns = "\r\n                    ^\\s*\\$[\\w\\.\\[\\]\\\'\\\"]+\\s*(?<range>=)\\s*(?<range>[^;]+);\r\n   " +
                "                 ";
            this.txtRules.AutoScrollMinSize = new System.Drawing.Size(2, 14);
            this.txtRules.BackBrush = null;
            this.txtRules.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.txtRules.CharHeight = 14;
            this.txtRules.CharWidth = 8;
            this.txtRules.ContextMenuStrip = this.cmsOpcionesTXT;
            this.txtRules.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtRules.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.txtRules.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRules.IsReplaceMode = false;
            this.txtRules.Language = FastColoredTextBoxNS.Language.Genexus;
            this.txtRules.LeftBracket = '{';
            this.txtRules.LeftBracket2 = '{';
            this.txtRules.Location = new System.Drawing.Point(3, 3);
            this.txtRules.Name = "txtRules";
            this.txtRules.Paddings = new System.Windows.Forms.Padding(0);
            this.txtRules.RightBracket = '}';
            this.txtRules.RightBracket2 = '}';
            this.txtRules.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.txtRules.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("txtRules.ServiceColors")));
            this.txtRules.Size = new System.Drawing.Size(800, 374);
            this.txtRules.TabIndex = 3;
            this.txtRules.Zoom = 100;
            // 
            // cmsOpcionesTXT
            // 
            this.cmsOpcionesTXT.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colapsarSeToolStripMenuItem,
            this.leccionToolStripMenuItem,
            this.colapsarTodoToolStripMenuItem,
            this.toolStripMenuItem4,
            this.asigmarMarcadorToolStripMenuItem,
            this.desAsignarMarcadorToolStripMenuItem,
            this.toolStripMenuItem5,
            this.buscarToolStripMenuItem,
            this.reemplazarToolStripMenuItem,
            this.irALineaToolStripMenuItem,
            this.toolStripMenuItem6,
            this.seleccionarTodoToolStripMenuItem});
            this.cmsOpcionesTXT.Name = "cmsOpcionesTXT";
            this.cmsOpcionesTXT.Size = new System.Drawing.Size(294, 204);
            // 
            // colapsarSeToolStripMenuItem
            // 
            this.colapsarSeToolStripMenuItem.Name = "colapsarSeToolStripMenuItem";
            this.colapsarSeToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.colapsarSeToolStripMenuItem.Text = "Colapsar Selección      ";
            this.colapsarSeToolStripMenuItem.Click += new System.EventHandler(this.colapsarSeToolStripMenuItem_Click);
            // 
            // leccionToolStripMenuItem
            // 
            this.leccionToolStripMenuItem.Name = "leccionToolStripMenuItem";
            this.leccionToolStripMenuItem.Size = new System.Drawing.Size(290, 6);
            // 
            // colapsarTodoToolStripMenuItem
            // 
            this.colapsarTodoToolStripMenuItem.Name = "colapsarTodoToolStripMenuItem";
            this.colapsarTodoToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.colapsarTodoToolStripMenuItem.Text = "Colapsar Todo  ";
            this.colapsarTodoToolStripMenuItem.Click += new System.EventHandler(this.colapsarTodoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(290, 6);
            // 
            // asigmarMarcadorToolStripMenuItem
            // 
            this.asigmarMarcadorToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.asigmarMarcadorToolStripMenuItem.Name = "asigmarMarcadorToolStripMenuItem";
            this.asigmarMarcadorToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.asigmarMarcadorToolStripMenuItem.Text = "Asigmar Marcador          [Ctrl+B]";
            this.asigmarMarcadorToolStripMenuItem.Click += new System.EventHandler(this.asigmarMarcadorToolStripMenuItem_Click);
            // 
            // desAsignarMarcadorToolStripMenuItem
            // 
            this.desAsignarMarcadorToolStripMenuItem.Name = "desAsignarMarcadorToolStripMenuItem";
            this.desAsignarMarcadorToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.desAsignarMarcadorToolStripMenuItem.Text = "DesAsignar Marcador      [Ctrl+Mayús.+B]";
            this.desAsignarMarcadorToolStripMenuItem.Click += new System.EventHandler(this.desAsignarMarcadorToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(290, 6);
            // 
            // buscarToolStripMenuItem
            // 
            this.buscarToolStripMenuItem.Name = "buscarToolStripMenuItem";
            this.buscarToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.buscarToolStripMenuItem.Text = "Buscar                                [Ctrl+F]";
            this.buscarToolStripMenuItem.Click += new System.EventHandler(this.buscarToolStripMenuItem_Click);
            // 
            // reemplazarToolStripMenuItem
            // 
            this.reemplazarToolStripMenuItem.Name = "reemplazarToolStripMenuItem";
            this.reemplazarToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.reemplazarToolStripMenuItem.Text = "Reemplazar                       [Ctrl+H]";
            this.reemplazarToolStripMenuItem.Click += new System.EventHandler(this.reemplazarToolStripMenuItem_Click);
            // 
            // irALineaToolStripMenuItem
            // 
            this.irALineaToolStripMenuItem.Name = "irALineaToolStripMenuItem";
            this.irALineaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.irALineaToolStripMenuItem.Text = "Ir a Linea                            [Ctrl+G]";
            this.irALineaToolStripMenuItem.Click += new System.EventHandler(this.irALineaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(290, 6);
            // 
            // seleccionarTodoToolStripMenuItem
            // 
            this.seleccionarTodoToolStripMenuItem.Name = "seleccionarTodoToolStripMenuItem";
            this.seleccionarTodoToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.seleccionarTodoToolStripMenuItem.Text = "Seleccionar Todo              [Ctrl+A]";
            this.seleccionarTodoToolStripMenuItem.Click += new System.EventHandler(this.seleccionarTodoToolStripMenuItem_Click);
            // 
            // tabCode
            // 
            this.tabCode.Controls.Add(this.txtCode);
            this.tabCode.ImageIndex = 2;
            this.tabCode.Location = new System.Drawing.Point(4, 23);
            this.tabCode.Name = "tabCode";
            this.tabCode.Padding = new System.Windows.Forms.Padding(3);
            this.tabCode.Size = new System.Drawing.Size(806, 380);
            this.tabCode.TabIndex = 1;
            this.tabCode.Text = "Codigo Fuente";
            this.tabCode.UseVisualStyleBackColor = true;
            // 
            // txtCode
            // 
            this.txtCode.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.txtCode.AutoIndentCharsPatterns = "\r\n                    ^\\s*\\$[\\w\\.\\[\\]\\\'\\\"]+\\s*(?<range>=)\\s*(?<range>[^;]+);\r\n   " +
                "                 ";
            this.txtCode.AutoScrollMinSize = new System.Drawing.Size(2, 14);
            this.txtCode.BackBrush = null;
            this.txtCode.BookmarkColor = System.Drawing.Color.IndianRed;
            this.txtCode.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.txtCode.CharHeight = 14;
            this.txtCode.CharWidth = 8;
            this.txtCode.ContextMenuStrip = this.cmsOpcionesTXT;
            this.txtCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCode.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCode.IsReplaceMode = false;
            this.txtCode.Language = FastColoredTextBoxNS.Language.Genexus;
            this.txtCode.LeftBracket = '{';
            this.txtCode.LeftBracket2 = '{';
            this.txtCode.Location = new System.Drawing.Point(3, 3);
            this.txtCode.Name = "txtCode";
            this.txtCode.Paddings = new System.Windows.Forms.Padding(0);
            this.txtCode.RightBracket = '}';
            this.txtCode.RightBracket2 = '}';
            this.txtCode.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.txtCode.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("txtCode.ServiceColors")));
            this.txtCode.Size = new System.Drawing.Size(800, 374);
            this.txtCode.TabIndex = 2;
            this.txtCode.Zoom = 100;
            // 
            // tabConditions
            // 
            this.tabConditions.Controls.Add(this.txtConditions);
            this.tabConditions.ImageIndex = 3;
            this.tabConditions.Location = new System.Drawing.Point(4, 23);
            this.tabConditions.Name = "tabConditions";
            this.tabConditions.Size = new System.Drawing.Size(806, 380);
            this.tabConditions.TabIndex = 2;
            this.tabConditions.Text = "Condiciones";
            this.tabConditions.UseVisualStyleBackColor = true;
            // 
            // txtConditions
            // 
            this.txtConditions.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.txtConditions.AutoIndentCharsPatterns = "\r\n                    ^\\s*\\$[\\w\\.\\[\\]\\\'\\\"]+\\s*(?<range>=)\\s*(?<range>[^;]+);\r\n   " +
                "                 ";
            this.txtConditions.AutoScrollMinSize = new System.Drawing.Size(2, 14);
            this.txtConditions.BackBrush = null;
            this.txtConditions.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.txtConditions.CharHeight = 14;
            this.txtConditions.CharWidth = 8;
            this.txtConditions.ContextMenuStrip = this.cmsOpcionesTXT;
            this.txtConditions.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtConditions.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.txtConditions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtConditions.IsReplaceMode = false;
            this.txtConditions.Language = FastColoredTextBoxNS.Language.Genexus;
            this.txtConditions.LeftBracket = '{';
            this.txtConditions.LeftBracket2 = '{';
            this.txtConditions.Location = new System.Drawing.Point(0, 0);
            this.txtConditions.Name = "txtConditions";
            this.txtConditions.Paddings = new System.Windows.Forms.Padding(0);
            this.txtConditions.RightBracket = '}';
            this.txtConditions.RightBracket2 = '}';
            this.txtConditions.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.txtConditions.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("txtConditions.ServiceColors")));
            this.txtConditions.Size = new System.Drawing.Size(806, 380);
            this.txtConditions.TabIndex = 3;
            this.txtConditions.Zoom = 100;
            // 
            // tabHelp
            // 
            this.tabHelp.Controls.Add(this.wbhelp);
            this.tabHelp.ImageIndex = 4;
            this.tabHelp.Location = new System.Drawing.Point(4, 23);
            this.tabHelp.Name = "tabHelp";
            this.tabHelp.Size = new System.Drawing.Size(806, 380);
            this.tabHelp.TabIndex = 3;
            this.tabHelp.Text = "Ayuda";
            this.tabHelp.UseVisualStyleBackColor = true;
            // 
            // wbhelp
            // 
            this.wbhelp.AllowNavigation = false;
            this.wbhelp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbhelp.IsWebBrowserContextMenuEnabled = false;
            this.wbhelp.Location = new System.Drawing.Point(0, 0);
            this.wbhelp.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbhelp.Name = "wbhelp";
            this.wbhelp.Size = new System.Drawing.Size(806, 380);
            this.wbhelp.TabIndex = 0;
            // 
            // tabDocument
            // 
            this.tabDocument.Controls.Add(this.wbdoc);
            this.tabDocument.ImageIndex = 5;
            this.tabDocument.Location = new System.Drawing.Point(4, 23);
            this.tabDocument.Name = "tabDocument";
            this.tabDocument.Size = new System.Drawing.Size(806, 380);
            this.tabDocument.TabIndex = 4;
            this.tabDocument.Text = "Documentacion";
            this.tabDocument.UseVisualStyleBackColor = true;
            // 
            // wbdoc
            // 
            this.wbdoc.AllowNavigation = false;
            this.wbdoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.wbdoc.IsWebBrowserContextMenuEnabled = false;
            this.wbdoc.Location = new System.Drawing.Point(0, 0);
            this.wbdoc.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbdoc.Name = "wbdoc";
            this.wbdoc.Size = new System.Drawing.Size(806, 380);
            this.wbdoc.TabIndex = 1;
            // 
            // tabvariables
            // 
            this.tabvariables.Controls.Add(this.splitContainer1);
            this.tabvariables.ForeColor = System.Drawing.Color.Blue;
            this.tabvariables.ImageIndex = 6;
            this.tabvariables.Location = new System.Drawing.Point(4, 23);
            this.tabvariables.Name = "tabvariables";
            this.tabvariables.Padding = new System.Windows.Forms.Padding(3);
            this.tabvariables.Size = new System.Drawing.Size(806, 380);
            this.tabvariables.TabIndex = 5;
            this.tabvariables.Text = "Variables y Atributos";
            this.tabvariables.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panelvariables);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel3);
            this.splitContainer1.Size = new System.Drawing.Size(800, 374);
            this.splitContainer1.SplitterDistance = 382;
            this.splitContainer1.TabIndex = 0;
            // 
            // panelvariables
            // 
            this.panelvariables.Controls.Add(this.groupBoxVars);
            this.panelvariables.Controls.Add(this.panel2);
            this.panelvariables.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelvariables.Location = new System.Drawing.Point(0, 0);
            this.panelvariables.Name = "panelvariables";
            this.panelvariables.Size = new System.Drawing.Size(382, 374);
            this.panelvariables.TabIndex = 0;
            // 
            // groupBoxVars
            // 
            this.groupBoxVars.Controls.Add(this.dgvVars);
            this.groupBoxVars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxVars.Location = new System.Drawing.Point(0, 42);
            this.groupBoxVars.Name = "groupBoxVars";
            this.groupBoxVars.Size = new System.Drawing.Size(382, 332);
            this.groupBoxVars.TabIndex = 2;
            this.groupBoxVars.TabStop = false;
            this.groupBoxVars.Text = "Listado de Variables";
            // 
            // dgvVars
            // 
            this.dgvVars.AllowUserToAddRows = false;
            this.dgvVars.AllowUserToDeleteRows = false;
            this.dgvVars.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvVars.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvVars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVars.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cid,
            this.cname,
            this.ctipo,
            this.ctamanio,
            this.cdecimal,
            this.colpicvar});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvVars.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvVars.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvVars.Location = new System.Drawing.Point(3, 16);
            this.dgvVars.Name = "dgvVars";
            this.dgvVars.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvVars.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvVars.RowHeadersVisible = false;
            this.dgvVars.Size = new System.Drawing.Size(376, 313);
            this.dgvVars.TabIndex = 1;
            // 
            // cid
            // 
            this.cid.DataPropertyName = "Id";
            this.cid.HeaderText = "Id";
            this.cid.Name = "cid";
            this.cid.ReadOnly = true;
            this.cid.Width = 30;
            // 
            // cname
            // 
            this.cname.DataPropertyName = "NombreVar";
            this.cname.HeaderText = "Nombre";
            this.cname.Name = "cname";
            this.cname.ReadOnly = true;
            // 
            // ctipo
            // 
            this.ctipo.DataPropertyName = "Type";
            this.ctipo.HeaderText = "Tipo";
            this.ctipo.Name = "ctipo";
            this.ctipo.ReadOnly = true;
            this.ctipo.Width = 90;
            // 
            // ctamanio
            // 
            this.ctamanio.DataPropertyName = "Length";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ctamanio.DefaultCellStyle = dataGridViewCellStyle2;
            this.ctamanio.HeaderText = "Tam";
            this.ctamanio.Name = "ctamanio";
            this.ctamanio.ReadOnly = true;
            this.ctamanio.Width = 40;
            // 
            // cdecimal
            // 
            this.cdecimal.DataPropertyName = "Decimales";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.cdecimal.DefaultCellStyle = dataGridViewCellStyle3;
            this.cdecimal.HeaderText = "Dec";
            this.cdecimal.Name = "cdecimal";
            this.cdecimal.ReadOnly = true;
            this.cdecimal.Width = 40;
            // 
            // colpicvar
            // 
            this.colpicvar.DataPropertyName = "Picture";
            this.colpicvar.HeaderText = "Picture";
            this.colpicvar.Name = "colpicvar";
            this.colpicvar.ReadOnly = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtFindVars);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(382, 42);
            this.panel2.TabIndex = 1;
            // 
            // txtFindVars
            // 
            this.txtFindVars.Location = new System.Drawing.Point(74, 14);
            this.txtFindVars.Name = "txtFindVars";
            this.txtFindVars.Size = new System.Drawing.Size(200, 20);
            this.txtFindVars.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Buscar";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBoxAttrs);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(414, 374);
            this.panel3.TabIndex = 1;
            // 
            // groupBoxAttrs
            // 
            this.groupBoxAttrs.Controls.Add(this.dgvAttrs);
            this.groupBoxAttrs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAttrs.Location = new System.Drawing.Point(0, 42);
            this.groupBoxAttrs.Name = "groupBoxAttrs";
            this.groupBoxAttrs.Size = new System.Drawing.Size(414, 332);
            this.groupBoxAttrs.TabIndex = 2;
            this.groupBoxAttrs.TabStop = false;
            this.groupBoxAttrs.Text = "Listado de Atributos";
            // 
            // dgvAttrs
            // 
            this.dgvAttrs.AllowUserToAddRows = false;
            this.dgvAttrs.AllowUserToDeleteRows = false;
            this.dgvAttrs.AllowUserToOrderColumns = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAttrs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvAttrs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAttrs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.Column1,
            this.ctitulo,
            this.dataGridViewTextBoxColumn5});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAttrs.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvAttrs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAttrs.Location = new System.Drawing.Point(3, 16);
            this.dgvAttrs.Name = "dgvAttrs";
            this.dgvAttrs.ReadOnly = true;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAttrs.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvAttrs.RowHeadersVisible = false;
            this.dgvAttrs.Size = new System.Drawing.Size(408, 313);
            this.dgvAttrs.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Tipo";
            this.dataGridViewTextBoxColumn3.HeaderText = "Tipo";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 90;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Tamanio";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn4.HeaderText = "Tam";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 40;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Decimals";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle8;
            this.Column1.HeaderText = "Dec";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 40;
            // 
            // ctitulo
            // 
            this.ctitulo.DataPropertyName = "Title";
            this.ctitulo.HeaderText = "Titulo";
            this.ctitulo.Name = "ctitulo";
            this.ctitulo.ReadOnly = true;
            this.ctitulo.Width = 120;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Picture";
            this.dataGridViewTextBoxColumn5.HeaderText = "Picture";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 70;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtFindAttr);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(414, 42);
            this.panel4.TabIndex = 1;
            // 
            // txtFindAttr
            // 
            this.txtFindAttr.Location = new System.Drawing.Point(74, 14);
            this.txtFindAttr.Name = "txtFindAttr";
            this.txtFindAttr.Size = new System.Drawing.Size(200, 20);
            this.txtFindAttr.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Buscar";
            // 
            // tabProp
            // 
            this.tabProp.ForeColor = System.Drawing.Color.Magenta;
            this.tabProp.Location = new System.Drawing.Point(4, 23);
            this.tabProp.Name = "tabProp";
            this.tabProp.Size = new System.Drawing.Size(806, 380);
            this.tabProp.TabIndex = 6;
            this.tabProp.Text = "Propiedades";
            this.tabProp.UseVisualStyleBackColor = true;
            // 
            // GxEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.paneltop);
            this.Name = "GxEditor";
            this.Size = new System.Drawing.Size(814, 444);
            this.paneltop.ResumeLayout(false);
            this.paneltop.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tsBarraOpciones.ResumeLayout(false);
            this.tsBarraOpciones.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tbObjeto.ResumeLayout(false);
            this.tabStructure.ResumeLayout(false);
            this.tabLayout.ResumeLayout(false);
            this.tabRules.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtRules)).EndInit();
            this.cmsOpcionesTXT.ResumeLayout(false);
            this.tabCode.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtCode)).EndInit();
            this.tabConditions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtConditions)).EndInit();
            this.tabHelp.ResumeLayout(false);
            this.tabDocument.ResumeLayout(false);
            this.tabvariables.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panelvariables.ResumeLayout(false);
            this.groupBoxVars.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVars)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBoxAttrs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttrs)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paneltop;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tbObjeto;
        private System.Windows.Forms.TabPage tabLayout;
        private System.Windows.Forms.TabPage tabRules;
        private System.Windows.Forms.TabPage tabCode;
        private System.Windows.Forms.TabPage tabConditions;
        private System.Windows.Forms.TabPage tabHelp;
        private System.Windows.Forms.WebBrowser wbhelp;
        private System.Windows.Forms.TabPage tabDocument;
        private System.Windows.Forms.WebBrowser wbdoc;
        private System.Windows.Forms.TabPage tabvariables;
        private System.Windows.Forms.TabPage tabProp;
        private System.Windows.Forms.Label lblTipoObjeto;
        private System.Windows.Forms.LinkLabel lblNombreObjeto;
        private System.Windows.Forms.Label lbldescrip;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panelvariables;
        private System.Windows.Forms.GroupBox groupBoxVars;
        private System.Windows.Forms.DataGridView dgvVars;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFindVars;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBoxAttrs;
        private System.Windows.Forms.DataGridView dgvAttrs;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtFindAttr;
        private System.Windows.Forms.Label label2;
        private FastColoredTextBoxNS.FastColoredTextBox txtRules;
        private FastColoredTextBoxNS.FastColoredTextBox txtCode;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.WebBrowser webDesign;
        private System.Windows.Forms.TabPage tabStructure;
        private System.Windows.Forms.WebBrowser wbStructure;
        private FastColoredTextBoxNS.FastColoredTextBox txtConditions;
        private System.Windows.Forms.ToolStrip tsBarraOpciones;
        private System.Windows.Forms.ToolStripSplitButton tssbOpciones;
        private System.Windows.Forms.ToolStripButton tsbClose;
        private System.Windows.Forms.ToolStripMenuItem verXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verificarVariablesNoUtilizadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tsbValidadorGX;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem buscarObjetoEnElModeloToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip cmsOpcionesTXT;
        private System.Windows.Forms.ToolStripMenuItem colapsarSeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator leccionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colapsarTodoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem asigmarMarcadorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desAsignarMarcadorToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem buscarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reemplazarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irALineaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem seleccionarTodoToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn cid;
        private System.Windows.Forms.DataGridViewTextBoxColumn cname;
        private System.Windows.Forms.DataGridViewTextBoxColumn ctipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ctamanio;
        private System.Windows.Forms.DataGridViewTextBoxColumn cdecimal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colpicvar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ctitulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;


    }
}
