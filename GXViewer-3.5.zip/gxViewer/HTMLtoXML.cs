using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Web;
using System.Data;
using System.Text.RegularExpressions;

namespace gxViewer
{
    public class HTMLtoGxXML
    {
        private static string _gxType = String.Empty;
        

        private static void SetPropertyForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            Dictionary<string, string> _dProperties = new Dictionary<string, string>();
            _gxType = String.Empty;

            mshtml.IHTMLDocument2 _FirstDoc = (mshtml.IHTMLDocument2)(new mshtml.HTMLDocument());
            _FirstDoc.write(_elem.outerHTML);
            mshtml.HTMLDocument _FirstD = (mshtml.HTMLDocument)_FirstDoc;

            foreach (mshtml.IHTMLElement _tableHTML in _FirstD.getElementsByTagName("TABLE"))
            {
                mshtml.HTMLTableClass _tab = (mshtml.HTMLTableClass)_tableHTML;

                if (_tab.className != null)
                {
                    if (_tab.className.Equals("gxcontent"))
                    {
                        bool _indicadorContinue2 = true;
                        foreach (mshtml.IHTMLElement _row in _tab.rows)
                        {
                            mshtml.HTMLTableRowClass _r = (mshtml.HTMLTableRowClass)_row;

                            int _indexCol = 0;
                            string _key = String.Empty;
                            string _value = String.Empty;
                            foreach (mshtml.IHTMLElement _cell in _r.cells)
                            {
                                _indexCol++;
                                if (((mshtml.HTMLTableCellClass)_cell).colSpan > 1)
                                {
                                    _indicadorContinue2 = false;
                                    break;
                                }

                                switch (_indexCol)
                                {
                                    case 1: _key = _cell.innerText; break;
                                    case 2: _value = _cell.innerText;
                                        _dProperties.Add(_key, _value);
                                        break;
                                }

                                if (_key.Equals("Name") && !String.IsNullOrEmpty(_value)) //Obtengo el Tipo de Objeto
                                {
                                    int _posFin = _cell.innerHTML.IndexOf(".bmp");
                                    int _posIni = _cell.innerHTML.IndexOf("/");
                                    if (_posFin > 0)
                                    {
                                        _gxType = _cell.innerHTML.Substring(_posIni + 1, (_posFin - (_posIni + 1)));
                                    }
                                }


                            }

                            if (!_indicadorContinue2)
                            {
                                break;
                            }

                        }

                        break;
                    }
                }
            }

            object _objret = Activator.CreateInstance(System.Type.GetType(String.Format("gxViewer.GxObject.{0}", _gxType)));

            _gxObject = _objret as GxObject.GXObj;

            GxObject.Info _info = new gxViewer.GxObject.Info();
            GxObject.KMW _kmw = new gxViewer.GxObject.KMW();
            GxObject.Model _model = new gxViewer.GxObject.Model();

            _kmw.Path = "DLA"; //Para Identificar que de DLYA
            _model.Id = "2";
            _model.Name = "Bantotal RPG/400";
            _model.Type = "Production";

            foreach (KeyValuePair<string, string> _prop in _dProperties)
            {
                switch (_prop.Key)
                {
                    case "Name": _info.Name = _prop.Value.Trim(); break;
                    case "Description": _info.Description = _prop.Value.Trim(); break;
                    case "Folder": _info.Folder = _prop.Value; break;
                    //case "Id": _model.Id = _prop.Value; break;
                    //case "Created": _gxObject. = _prop.Value; break;
                    case "Updated": _gxObject.LastUpdate = _prop.Value; break;
                    //case "Consolidated": _gxObject. = _prop.Value; break;
                    default:
                        break;
                }

            }
            _gxObject.KMW = _kmw;
            _gxObject.Info = _info;
        }
        private static void SetRulesForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            
            //mshtml.IHTMLDocument2 _xDocHTML = (mshtml.IHTMLDocument2)(new mshtml.HTMLDocument());
            //_xDocHTML.write(_elem.outerHTML);
            //mshtml.HTMLDocument _xDoc = (mshtml.HTMLDocument)_xDocHTML;
            string _Rules = _elem.innerText; //_xDoc.documentElement.innerText;
            _gxObject.Rules = _Rules;

        }
        private static void SetEventsForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            string _Events = _elem.innerText; 
            _gxObject.Source = _Events;

        }
        private static void SetSubRoutinesForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            string _SubRoutines = _elem.innerText;
            _gxObject.Subroutines = _SubRoutines;
        }
        private static void SetConditionsForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            string _Conditions = _elem.innerText;
            _gxObject.Conditions = _Conditions;

        }
        private static void SetDocumForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            string _Events = _elem.innerHTML;
            GxObject.Documentation _doc = new gxViewer.GxObject.Documentation();
            _doc.Source = _Events;
            _gxObject.Documentation = _doc;

        }
        private static void SetVariablesForHTML(ref GxObject.GXObj _gxObject, mshtml.IHTMLElement _elem)
        {
            mshtml.IHTMLDocument2 _dh = (mshtml.IHTMLDocument2)(new mshtml.HTMLDocument());
            _dh.write(_elem.outerHTML);
            mshtml.HTMLDocument _d = (mshtml.HTMLDocument)_dh;

            mshtml.IHTMLElementCollection _tbls = _d.getElementsByTagName("TABLE");
            
            List<GxObject.Variable> _vars = new List<gxViewer.GxObject.Variable>();


            DataTable _dtVars = new DataTable("variables");
            _dtVars.Columns.Add("Name");
            _dtVars.Columns.Add("Description");
            _dtVars.Columns.Add("Type");
            _dtVars.Columns.Add("Length");
            _dtVars.Columns.Add("Decimals");
            _dtVars.Columns.Add("Picture");

            foreach (mshtml.IHTMLElement _t in _tbls)
            {
                mshtml.HTMLTableClass _table = (mshtml.HTMLTableClass)_t;

                int _indexrow = 0;
                
                foreach (mshtml.IHTMLElement _row in _table.rows)
                {
                    mshtml.HTMLTableRowClass _r = (mshtml.HTMLTableRowClass)_row;
                    if (_indexrow > 0) //cabecera
                    {
                        int _col = 0;
                        DataRow _rVar = _dtVars.NewRow();
                        foreach (mshtml.IHTMLElement _c  in _r.cells)
                        {
                            _rVar[_col] = _c.innerText;
                            _col++;
                        }
                        _dtVars.Rows.Add(_rVar);

                    }
                    _indexrow++;
                }                
            }


            foreach (DataRow _r in _dtVars.Rows)
            {
                GxObject.Variable _v = new gxViewer.GxObject.Variable();
                _v.Name = _r["Name"].ToString();
                _v.Title = _r["Description"].ToString();
                _v.Type = _r["Type"].ToString();
                _v.Length = int.Parse( _r["Length"].ToString());
                _v.Decimals = ( String.IsNullOrEmpty( _r["Decimals"].ToString() ) ? 0 : int.Parse(_r["Decimals"].ToString()) );
                _v.Picture = _r["Picture"].ToString();

                _vars.Add(_v);
            }
            _gxObject.Variables = _vars.ToArray();

        }

        public static GxObject.GXObj ConvertXML(string _RutaHTML)
        {
           //    Dim xmldoc As New Xml.XmlDocumentxmldoc.Load("your filename here")
            string _html = System.IO.File.ReadAllText(_RutaHTML, Encoding.Default);

            mshtml.IHTMLDocument2 _docxHtml = (mshtml.IHTMLDocument2)(new mshtml.HTMLDocument());
            _docxHtml.clear();
            _docxHtml.write(_html);
            mshtml.HTMLDocument _doc = (mshtml.HTMLDocument)_docxHtml;

            GxObject.GXObj _gxObject = new gxViewer.GxObject.GXObj();
            Dictionary<string, string> _dProperties = new Dictionary<string, string>();


            mshtml.IHTMLElementCollection _Divs = _doc.getElementsByTagName("DIV");
            string _NameObject = String.Empty;
            int _IndicadorContinue = 0;
            foreach (mshtml.IHTMLElement _elem in _Divs)
            {
                bool _continue = false;

                if (_elem.id != null )
                {
                    if (String.IsNullOrEmpty(_NameObject))
                    {
                        _NameObject = _elem.id;
                        _continue = false;
                    }

                    switch (_elem.id)
                    {
                        case "wholeNugget":
                        case "formPart":
                        case "layoutPart":
                        case "htmlPart":
                            _continue = false;
                            break;
                        case "content":
                            _continue = true;
                            _IndicadorContinue++;
                            break;

                    }
                    
                }

                if (_continue)
                {

                    if (_IndicadorContinue == 1) //Solo la primera vez
                    {
                        SetPropertyForHTML(ref _gxObject, _elem);
                        _IndicadorContinue++;
                    }
                    else
                    {

                        //cargamos las Reglas
                        //parent rule
                        switch (_elem.parentElement.id)
                        {
                            case "formPart":   //FORM
                            case "layoutPart": //LAYOUT
                            case "htmlPart":   //WEB FORM
                                break;

                            case "rule":   //Reglas
                                SetRulesForHTML(ref _gxObject, _elem);
                                break;

                            case "evt":  //Eventos
                                SetEventsForHTML(ref _gxObject, _elem);
                                break;

                            case "subs":  //Subrutinas
                                SetSubRoutinesForHTML(ref _gxObject, _elem);
                                break;

                            case "cond":  //Condiciones
                                SetConditionsForHTML(ref _gxObject, _elem);
                                break;
                            
                            case "var":  //Variables
                                SetVariablesForHTML(ref _gxObject, _elem);
                                break;

                            case "doc":  //Documentacion
                                SetDocumForHTML(ref _gxObject, _elem);
                                break;
                            
                            default:
                                break;
                        }


                       
                        
                    }
                }

            }


            return _gxObject;

        
        }




    }
}
