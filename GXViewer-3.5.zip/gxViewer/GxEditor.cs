using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using gxViewer.GxObject;
using System.Xml;


namespace gxViewer
{
    public partial class GxEditor : UserControl
    {
        private string _XMLSTR = String.Empty;
        private object _objetoGX;
        private string _text;
        private DataTable _dtvars;
        private DataTable _dtattrs;

        public override string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        public object objetoGX
        {
            get { return _objetoGX; }
            set { _objetoGX = value; }
        }


        public GxEditor(string _XMLpath, object _tipo)
        {
            _XMLSTR = _XMLpath;
            InitializeComponent();

            //
            System.Threading.Thread _LeeObj = new System.Threading.Thread(PrepareObject);

            try
            {
                _LeeObj.IsBackground = true;
                _LeeObj.Priority = System.Threading.ThreadPriority.Highest;
                _LeeObj.Start();
            }
            catch (Exception ex)
            {
                _LeeObj.Abort();
                _LeeObj = null;
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        public GxEditor()
        {
            InitializeComponent();
            FastColoredTextBoxNS.SyntaxHighlighter _syntax = new FastColoredTextBoxNS.SyntaxHighlighter();

            this.txtRules.Language = FastColoredTextBoxNS.Language.Genexus;
            this.txtRules.SyntaxHighlighter.IgnoreIFScafold = true;
            this.txtRules.OnSyntaxHighlight(new FastColoredTextBoxNS.TextChangedEventArgs(this.txtRules.Range));

            this.txtConditions.SyntaxHighlighter.IgnoreIFScafold = true;
            this.txtConditions.Language = FastColoredTextBoxNS.Language.Genexus;
            this.txtConditions.OnSyntaxHighlight(new FastColoredTextBoxNS.TextChangedEventArgs(this.txtConditions.Range));

            //_syntax.HighlightSyntax( 

            this.Load += new EventHandler(GxEditor_Load);
        }

       

        void GxEditor_Load(object sender, EventArgs e)
        {

            this.PrepareObject();
            
            

            tbObjeto.SelectedTab = tabCode;
        }

        private void paneltop_Paint(object sender, PaintEventArgs e)
        {

        }


        private void PrepareObject()
        {
            if (_objetoGX != null)
            {
                GxObject.GXObj _obj = (GxObject.GXObj)_objetoGX;
                lblTipoObjeto.Text = _obj.Tipo;
                lblNombreObjeto.Text = _obj.Info.Name;
                lbldescrip.Text = _obj.Info.Description;


                if (_obj.Tipo == "Transaction")
                {
                    tbObjeto.TabPages.RemoveByKey("tabLayout");
                    Transaction _trn = ((Transaction)_obj);
                    wbStructure.DocumentText = GxEditorHelper.Transaction.GetHTMLStruct(_trn, imageList1);
                }
                else
                {
                    tbObjeto.TabPages.RemoveByKey("tabStructure");
                    string _strHtml = @"<BR><BR><div>No se ha trabajado esta opcion</div>";


                    switch (_obj.Tipo)
                    {
                        case "WorkPanel":
                            WorkPanel _wpn = ((WorkPanel)_obj);
                            //GxEditorHelper.WorkPanel.PrepareLayoutXML(_wpn);
                            _strHtml =  GxEditorHelper.WorkPanel.GetHTMLDesign(_wpn, imageList1);
                            break;

                        case "Procedure":
                            Procedure _prc = ((Procedure)_obj);
                            //GxEditorHelper.WorkPanel.PrepareLayoutXML(_wpn);
                            _strHtml = GxEditorHelper.Procedure.GetHTMLDesign(_prc, imageList1);
                            break;


                        case "Report":
                            Report _rpt = ((Report)_obj);
                            //GxEditorHelper.WorkPanel.PrepareLayoutXML(_wpn);
                            _strHtml = GxEditorHelper.Report.GetHTMLDesign(_rpt, imageList1);
                            break;

                        default:
                            break;
                    }

                    webDesign.DocumentText = _strHtml;
                }



                if (_obj.Documentation != null) { wbdoc.DocumentText = _obj.Documentation.Source; }
                if (_obj.Help != null) { wbhelp.DocumentText = _obj.Help.Source; }
                txtRules.Text = _obj.Rules;

                txtCode.Text = _obj.Source;
                if (_obj.Subroutines != null)
                {
                    txtCode.AppendText( _obj.Subroutines );
                }

                txtConditions.Text = _obj.Conditions;


                if (_obj.Variables != null) 
                {
                    dgvVars.AutoGenerateColumns = false;
                    foreach (Variable v in _obj.Variables)
                    {
                        if (!String.IsNullOrEmpty(v.BasedOn) && v.Length <= 0)
                        {
                            if (_obj.GXAtts != null)
                            {
                                GxObject.GXAtt _att = _obj.GXAtributos[v.BasedOn];
                                if (_att != null)
                                {
                                    v.Length = _att.Tamanio;
                                    v.Decimals = _att.Decimals;
                                    //v.Picture = _att.Picture;
                                }
                            }
                        }
                    }



                    DataTable _dtpvars = Functions.ConvertToDataTable(_obj.Variables);
                    _dtpvars.Columns.Add("NombreVar", typeof(string), "IIF(Rows > 0, ( IIF(Columns > 0, Name + ' (' + Rows + ',' + Columns + ')'  , Name + ' (' + Rows + ')' )  )  ,Name)");

                    dgvVars.DataSource = _dtpvars;
                    groupBoxVars.Text = String.Format("Listado de variables ({0})", _obj.Variables.Length);
                    txtFindVars.TextChanged += new EventHandler(txtFindVars_TextChanged);
                }

                if (_obj.GXAtts != null)
                {
                    dgvAttrs.AutoGenerateColumns = false;
                    dgvAttrs.DataSource = Functions.ConvertToDataTable(_obj.GXAtts);
                    groupBoxAttrs.Text = String.Format("Listado de atributos ({0})", _obj.GXAtts.Length);
                    txtFindAttr.TextChanged += new EventHandler(txtFindAttr_TextChanged);
                }

                PropertyGrid propertyGrid = new PropertyGrid();
                propertyGrid.CommandsVisibleIfAvailable = true;
                propertyGrid.LargeButtons = false;
                propertyGrid.LineColor = System.Drawing.SystemColors.ScrollBar;
                propertyGrid.Location = new System.Drawing.Point(12, 12);
                propertyGrid.Name = String.Format("propertyGrid1{0}", lblNombreObjeto.Text);
                propertyGrid.SelectedObject = _obj;
                propertyGrid.Dock = DockStyle.Fill;
                propertyGrid.Text = "Propiedades";
                tabProp.ImageIndex = 8;
                tabProp.Controls.Add(propertyGrid);
            }
 
        }

        void txtFindAttr_TextChanged(object sender, EventArgs e)
        {
            if (_dtattrs == null) { _dtattrs = (DataTable)dgvAttrs.DataSource; }
            System.Data.DataView _dv = _dtattrs.DefaultView;
            _dv.RowFilter = String.Format("Name LIKE '%{0}%'", txtFindAttr.Text.Replace("'", String.Empty).Replace("\"", String.Empty));
            _dv.RowStateFilter = DataViewRowState.CurrentRows;
            DataTable _dtfiltrado = _dv.ToTable();
            dgvAttrs.DataSource = _dtfiltrado;
            groupBoxAttrs.Text = String.Format("Listado de atributos ({0})", _dtfiltrado.Rows.Count);
        }

        void txtFindVars_TextChanged(object sender, EventArgs e)
        {
            if (_dtvars == null) { _dtvars = (DataTable)dgvVars.DataSource; }
            System.Data.DataView _dv = _dtvars.DefaultView;
            _dv.RowFilter = String.Format("Name LIKE '%{0}%'", txtFindVars.Text.Replace("'",String.Empty).Replace("\"",String.Empty));
            _dv.RowStateFilter = DataViewRowState.CurrentRows;
            DataTable _dtfiltrado = _dv.ToTable();
            dgvVars.DataSource = _dtfiltrado;
            groupBoxVars.Text = String.Format("Listado de variables ({0})", _dtfiltrado.Rows.Count);

        }
        

        private void tsbClose_Click(object sender, EventArgs e)
        {
            try
            {
                TabPage _tab = (TabPage)this.Parent;
                //if (MessageBox.Show( String.Format("�Esta seguro de Cerrar el Objeto \"{0}\" ?",_tab.Text), "GxViewer",  MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                //{
                TabControl _tabMain = (TabControl)_tab.Parent;
                _tabMain.TabPages.Remove(_tab);
                _tabMain.SelectedIndex = _tabMain.TabPages.Count - 1;
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
        }

        private void tsbValidadorGX_Click(object sender, EventArgs e)
        {
            try
            {
                gxViewer.GxValidador.ValidatorGX _objValidator = new gxViewer.GxValidador.ValidatorGX((GXObj)_objetoGX);
                GxValidador.frmValidator _fVal = new GxValidador.frmValidator(_objValidator);
                _fVal.Show(this);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }   

            
            
        }

        private void verificarVariablesNoUtilizadasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void verXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ( _objetoGX != null)
            {
                frmViewXML _fXML = new frmViewXML();
                
                string _titulo = String.Format("{0} : {1} ({2})",lblTipoObjeto.Text,lblNombreObjeto.Text,lbldescrip.Text);
                _fXML.SetTitle(_titulo);

                string _XMLObject = ((GXObj)_objetoGX).XMLObj;
                System.Xml.Linq.XDocument _doc = System.Xml.Linq.XDocument.Parse(_XMLObject);
                _XMLObject = _doc.ToString();

                _doc = null;
                _fXML.LoadString(_XMLObject);
                _fXML.Show(this);                
                
            }
        }

        private FastColoredTextBoxNS.FastColoredTextBox GetMainTXT(object sender)
        {
            ToolStripItem item = (ToolStripItem)sender;
            FastColoredTextBoxNS.FastColoredTextBox _txtret = null;

            if (item != null) 
            { 
                ContextMenuStrip owner = item.Owner as ContextMenuStrip; 
                if (owner != null) 
                {
                    _txtret = (FastColoredTextBoxNS.FastColoredTextBox)owner.SourceControl ;
                } 
            }
            return _txtret;

        }



        private void colapsarSeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.CollapseBlock(_txt.Selection.Start.iLine, _txt.Selection.End.iLine);
            }
        }

        private void colapsarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.CollapseAllFoldingBlocks();
            }
        }

        private void asigmarMarcadorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.BookmarkLine(_txt.Selection.Start.iLine);
            }
        }

        private void desAsignarMarcadorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.UnbookmarkLine(_txt.Selection.Start.iLine);
            }
        }

        private void buscarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.ShowFindDialog();
            }
        }

        private void reemplazarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.ShowReplaceDialog();
            }
        }

        private void irALineaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.ShowGoToDialog();
            }
        }

        private void seleccionarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FastColoredTextBoxNS.FastColoredTextBox _txt = GetMainTXT(sender);
            if (_txt != null)
            {
                _txt.SelectAll();
            }
        }

        private void buscarObjetoEnElModeloToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }



        

        


    }
}
