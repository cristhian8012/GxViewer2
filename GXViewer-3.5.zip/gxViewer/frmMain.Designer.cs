﻿namespace gxViewer
{
    partial class frmMain
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tvObjetos = new System.Windows.Forms.TreeView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtFindTreeview = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabContents = new System.Windows.Forms.TabControl();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tpIndex = new System.Windows.Forms.TabPage();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.nuevoArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.abrirArchivoGXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.convertirHtmlDLAEnXPWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.convertirXPWEnXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMIguardarArchivosAbiertos = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.newEditorHighlighToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbOpen = new System.Windows.Forms.ToolStripSplitButton();
            this.buscarObjetosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.obtenerXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbdconfig = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsbdHelp = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsbAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabContents.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 601);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1134, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1,
            this.tsbOpen,
            this.tsbdconfig,
            this.tsbdHelp});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1134, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(1134, 576);
            this.splitContainer1.SplitterDistance = 225;
            this.splitContainer1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 576);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tvObjetos);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 40);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(225, 536);
            this.panel4.TabIndex = 2;
            // 
            // tvObjetos
            // 
            this.tvObjetos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvObjetos.FullRowSelect = true;
            this.tvObjetos.Location = new System.Drawing.Point(0, 0);
            this.tvObjetos.Name = "tvObjetos";
            this.tvObjetos.Size = new System.Drawing.Size(225, 536);
            this.tvObjetos.TabIndex = 0;
            this.tvObjetos.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvObjetos_NodeMouseDoubleClick);
            this.tvObjetos.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tvObjetos_KeyDown);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtFindTreeview);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(225, 40);
            this.panel3.TabIndex = 1;
            // 
            // txtFindTreeview
            // 
            this.txtFindTreeview.Location = new System.Drawing.Point(49, 9);
            this.txtFindTreeview.Name = "txtFindTreeview";
            this.txtFindTreeview.Size = new System.Drawing.Size(156, 20);
            this.txtFindTreeview.TabIndex = 3;
            this.txtFindTreeview.TextChanged += new System.EventHandler(this.txtFindTreeview_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "&Buscar";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tabContents);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(905, 576);
            this.panel2.TabIndex = 0;
            // 
            // tabContents
            // 
            this.tabContents.Controls.Add(this.tpIndex);
            this.tabContents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabContents.ImageList = this.imageList1;
            this.tabContents.ItemSize = new System.Drawing.Size(45, 23);
            this.tabContents.Location = new System.Drawing.Point(0, 0);
            this.tabContents.Multiline = true;
            this.tabContents.Name = "tabContents";
            this.tabContents.SelectedIndex = 0;
            this.tabContents.ShowToolTips = true;
            this.tabContents.Size = new System.Drawing.Size(905, 576);
            this.tabContents.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "workpanel");
            this.imageList1.Images.SetKeyName(1, "procedure");
            this.imageList1.Images.SetKeyName(2, "dataview");
            this.imageList1.Images.SetKeyName(3, "transaction");
            this.imageList1.Images.SetKeyName(4, "folder");
            this.imageList1.Images.SetKeyName(5, "report");
            // 
            // tpIndex
            // 
            this.tpIndex.BackColor = System.Drawing.Color.White;
            this.tpIndex.BackgroundImage = global::gxViewer.Properties.Resources.GxViewer;
            this.tpIndex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tpIndex.Location = new System.Drawing.Point(4, 27);
            this.tpIndex.Name = "tpIndex";
            this.tpIndex.Padding = new System.Windows.Forms.Padding(3, 3, 10, 3);
            this.tpIndex.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tpIndex.Size = new System.Drawing.Size(897, 545);
            this.tpIndex.TabIndex = 0;
            this.tpIndex.Text = "Index";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoArchivoToolStripMenuItem,
            this.toolStripMenuItem1,
            this.abrirArchivoGXToolStripMenuItem,
            this.toolStripMenuItem2,
            this.convertirHtmlDLAEnXPWToolStripMenuItem,
            this.toolStripMenuItem3,
            this.convertirXPWEnXMLToolStripMenuItem,
            this.toolStripMenuItem5,
            this.TSMIguardarArchivosAbiertos,
            this.toolStripMenuItem6,
            this.newEditorHighlighToolStripMenuItem});
            this.toolStripSplitButton1.Image = global::gxViewer.Properties.Resources.nuevo_on;
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(80, 22);
            this.toolStripSplitButton1.Text = "&Archivo";
            // 
            // nuevoArchivoToolStripMenuItem
            // 
            this.nuevoArchivoToolStripMenuItem.Name = "nuevoArchivoToolStripMenuItem";
            this.nuevoArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.nuevoArchivoToolStripMenuItem.Text = "Nuevo Archivo";
            this.nuevoArchivoToolStripMenuItem.Click += new System.EventHandler(this.nuevoArchivoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(256, 6);
            // 
            // abrirArchivoGXToolStripMenuItem
            // 
            this.abrirArchivoGXToolStripMenuItem.Name = "abrirArchivoGXToolStripMenuItem";
            this.abrirArchivoGXToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.abrirArchivoGXToolStripMenuItem.Text = "Abrir Archivo GX";
            this.abrirArchivoGXToolStripMenuItem.Click += new System.EventHandler(this.abrirArchivoGXToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(256, 6);
            // 
            // convertirHtmlDLAEnXPWToolStripMenuItem
            // 
            this.convertirHtmlDLAEnXPWToolStripMenuItem.Name = "convertirHtmlDLAEnXPWToolStripMenuItem";
            this.convertirHtmlDLAEnXPWToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.convertirHtmlDLAEnXPWToolStripMenuItem.Text = "Convertir Html DLA en XPW";
            this.convertirHtmlDLAEnXPWToolStripMenuItem.Click += new System.EventHandler(this.convertirHtmlDLAEnXPWToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(256, 6);
            // 
            // convertirXPWEnXMLToolStripMenuItem
            // 
            this.convertirXPWEnXMLToolStripMenuItem.Name = "convertirXPWEnXMLToolStripMenuItem";
            this.convertirXPWEnXMLToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.convertirXPWEnXMLToolStripMenuItem.Text = "Convertir (XPW, XPZ) en XML";
            this.convertirXPWEnXMLToolStripMenuItem.Click += new System.EventHandler(this.convertirXPWEnXMLToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(256, 6);
            // 
            // TSMIguardarArchivosAbiertos
            // 
            this.TSMIguardarArchivosAbiertos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSMIguardarArchivosAbiertos.ForeColor = System.Drawing.Color.Navy;
            this.TSMIguardarArchivosAbiertos.Name = "TSMIguardarArchivosAbiertos";
            this.TSMIguardarArchivosAbiertos.Size = new System.Drawing.Size(259, 22);
            this.TSMIguardarArchivosAbiertos.Text = "Guardar Archivos Abiertos";
            this.TSMIguardarArchivosAbiertos.Click += new System.EventHandler(this.TSMIguardarArchivosAbiertos_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(256, 6);
            // 
            // newEditorHighlighToolStripMenuItem
            // 
            this.newEditorHighlighToolStripMenuItem.Name = "newEditorHighlighToolStripMenuItem";
            this.newEditorHighlighToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.newEditorHighlighToolStripMenuItem.Text = "Editor Highligh (GX, XML, SQL, etc)";
            this.newEditorHighlighToolStripMenuItem.Click += new System.EventHandler(this.newEditorHighlighToolStripMenuItem_Click);
            // 
            // tsbOpen
            // 
            this.tsbOpen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buscarObjetosToolStripMenuItem,
            this.toolStripMenuItem4,
            this.obtenerXMLToolStripMenuItem});
            this.tsbOpen.Image = global::gxViewer.Properties.Resources.informacion;
            this.tsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbOpen.Name = "tsbOpen";
            this.tsbOpen.Size = new System.Drawing.Size(103, 22);
            this.tsbOpen.Text = "Modelos GX";
            // 
            // buscarObjetosToolStripMenuItem
            // 
            this.buscarObjetosToolStripMenuItem.Name = "buscarObjetosToolStripMenuItem";
            this.buscarObjetosToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.buscarObjetosToolStripMenuItem.Text = "Buscar Objetos";
            this.buscarObjetosToolStripMenuItem.Click += new System.EventHandler(this.buscarObjetosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(150, 6);
            // 
            // obtenerXMLToolStripMenuItem
            // 
            this.obtenerXMLToolStripMenuItem.Name = "obtenerXMLToolStripMenuItem";
            this.obtenerXMLToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.obtenerXMLToolStripMenuItem.Text = "Obtener XML";
            this.obtenerXMLToolStripMenuItem.Click += new System.EventHandler(this.obtenerXMLToolStripMenuItem_Click);
            // 
            // tsbdconfig
            // 
            this.tsbdconfig.Enabled = false;
            this.tsbdconfig.Image = global::gxViewer.Properties.Resources.editar_on;
            this.tsbdconfig.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbdconfig.Name = "tsbdconfig";
            this.tsbdconfig.Size = new System.Drawing.Size(112, 22);
            this.tsbdconfig.Text = "Configuración";
            this.tsbdconfig.ToolTipText = "Configuración";
            // 
            // tsbdHelp
            // 
            this.tsbdHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbAbout,
            this.toolStripSeparator1,
            this.tsbHelp});
            this.tsbdHelp.Image = global::gxViewer.Properties.Resources.informacion;
            this.tsbdHelp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbdHelp.Name = "tsbdHelp";
            this.tsbdHelp.Size = new System.Drawing.Size(70, 22);
            this.tsbdHelp.Text = "Ayuda";
            // 
            // tsbAbout
            // 
            this.tsbAbout.Name = "tsbAbout";
            this.tsbAbout.Size = new System.Drawing.Size(138, 22);
            this.tsbAbout.Text = "Acerca de ...";
            this.tsbAbout.Click += new System.EventHandler(this.tsbAbout_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(135, 6);
            // 
            // tsbHelp
            // 
            this.tsbHelp.Name = "tsbHelp";
            this.tsbHelp.Size = new System.Drawing.Size(138, 22);
            this.tsbHelp.Text = "Ayuda";
            // 
            // frmMain
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 623);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "GX Viewer - ";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.frmMain_DragDrop);
            this.DragOver += new System.Windows.Forms.DragEventHandler(this.frmMain_DragOver);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tabContents.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TreeView tvObjetos;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabContents;
        private System.Windows.Forms.TabPage tpIndex;
        private System.Windows.Forms.ToolStripDropDownButton tsbdconfig;
        private System.Windows.Forms.ToolStripDropDownButton tsbdHelp;
        private System.Windows.Forms.ToolStripMenuItem tsbAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsbHelp;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtFindTreeview;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem nuevoArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem abrirArchivoGXToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem convertirHtmlDLAEnXPWToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem convertirXPWEnXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton tsbOpen;
        private System.Windows.Forms.ToolStripMenuItem buscarObjetosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem obtenerXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem TSMIguardarArchivosAbiertos;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem newEditorHighlighToolStripMenuItem;
    }
}