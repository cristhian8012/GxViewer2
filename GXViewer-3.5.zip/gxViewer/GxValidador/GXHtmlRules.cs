﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using gxViewer.GxObject;

namespace gxViewer.GxValidador
{
    public static class GXHtmlRules
    {
        private static GXObj _Objeto;

        public static void LoadVars(GXObj _Obj)
        {
            _Objeto = _Obj;

        }


        public static void ValHardCode(GXValRegla _Regla)
        {

        }

        public static void ValWarning(GXValRegla _Regla)
        {

        }

        public static void ValVarNoUse(GXValRegla _Regla)
        {
            StringBuilder _htmlStruct = new StringBuilder();

            string _titulo = @"<div>
                                <span class='TableVariablesTitulo'>#TITLE#</span><br>
                                <span class='TableVariablesSubTitulo'>Se encontraron un total de #NRO# variables no utilizadas:</span>
                                <br>
                                <table width='691' cellpadding='0' cellspacing='0'  class='TableVariablesNoUsada'>
                                ";
            _titulo = _titulo.Replace("#TITLE#", _Regla.Decripcion).Replace("#NRO#", _Regla.ListaConcidencias.Count.ToString());

            _htmlStruct.AppendLine(_titulo);


            int _NroVar = 1;
            string _v1 = String.Empty;
            string _v2 = String.Empty;
            string _v3 = String.Empty;
            string _v4 = String.Empty;
            string _v5 = String.Empty;
            string _filaret = String.Empty;
            string _FilaHtml = @"
                  <tr class='FilaVariablesNoUsada'>
                    <td class='CeldaVariablesNoUsada'>&nbsp;#V1#</td>
                    <td class='CeldaVariablesNoUsada'>&nbsp;#V2#</td>
                    <td class='CeldaVariablesNoUsada'>&nbsp;#V3#</td>
                    <td class='CeldaVariablesNoUsada'>&nbsp;#V4#</td>
                    <td class='CeldaVariablesNoUsada'>&nbsp;#V5#</td>
                  </tr>";

            //_Regla.ListaConcidencias.Sort

            //List<Coincidencia> _listaOrdenada = _Regla.ListaConcidencias.Sort(delegate(Coincidencia n1, Coincidencia n2) { return n1.Linea.CompareTo((n2.Linea); });
            _Regla.ListaConcidencias.Sort(Coincidencia.LineaComparison);

            foreach (Coincidencia _c in _Regla.ListaConcidencias)
            {

                _filaret = string.Empty;
                switch (_NroVar)
                {
                    case 1: _v1 = _c.Linea; _NroVar++; break;
                    case 2: _v2 = _c.Linea; _NroVar++; break;
                    case 3: _v3 = _c.Linea; _NroVar++; break;
                    case 4: _v4 = _c.Linea; _NroVar++; break;
                    case 5: _v5 = _c.Linea;
                        _NroVar = 0;
                        _filaret = _FilaHtml.Replace("#V1#", _v1).Replace("#V2#", _v2).Replace("#V3#", _v3).Replace("#V4#", _v4).Replace("#V5#", _v5);
                        _htmlStruct.AppendLine(_filaret);

                        _v1 = String.Empty;
                        _v2 = String.Empty;
                        _v3 = String.Empty;
                        _v4 = String.Empty;
                        _v5 = String.Empty;

                        _NroVar = 1;
                        break;
                }
            }
            if ( (_NroVar > 0 && _NroVar <= 5) && _filaret == string.Empty )
            {
                _filaret = _FilaHtml.Replace("#V1#", _v1).Replace("#V2#", _v2).Replace("#V3#", _v3).Replace("#V4#", _v4).Replace("#V5#", _v5);
                _htmlStruct.AppendLine(_filaret);
            }

            _htmlStruct.AppendLine("</table></div>");

            _Regla._OutPutHTML = _htmlStruct.ToString();

        }


        public static void ValVarNoUse2(GXValRegla _Regla)
        {

        }
        public static void ValDefinedBy(GXValRegla _Regla)
        {

        }

        public static void ValErrorWhere(GXValRegla _Regla)
        {

        }

        public static void ValDocument(GXValRegla _Regla)
        {

        }

        public static void ValErrorCALL(GXValRegla _Regla)
        {

        }

        public static void ValWordRest(GXValRegla _Regla)
        {

        }


    }
}
