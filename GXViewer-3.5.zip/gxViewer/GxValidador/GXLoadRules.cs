﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using gxViewer.GxObject;

namespace gxViewer.GxValidador
{
    public static class GXLoadRules
    {
        private static GXObj _Objeto;
        private static string _totalCode = String.Empty;
        private static string _varsInLayout = String.Empty;

        public static void LoadVars(GXObj _Obj)
        {
            _Objeto = _Obj;
            _totalCode = _Objeto.GetTotalSource();
            _varsInLayout = _Objeto.GetVariablesInLayout();

        }


        public static void ValHardCode(GXValRegla _Regla)
        {

        }

        public static void ValWarning(GXValRegla _Regla)
        {

        }

        public static void ValVarNoUse(GXValRegla _Regla)
        {
            List<Variable> _lstVarUsada = new List<Variable>();
            List<Variable> _lstVarNOUsada = new List<Variable>();

            foreach (Variable _var in _Objeto.Variables)
            {
                if (_totalCode.Contains(_var.Name2) || _varsInLayout.Contains(_var.Name2))
                {
                    _lstVarUsada.Add(_var);
                }
                else
                {
                    switch (_var.Name2)
                    {
                        case "&today":
                        case "&pgmname":
                        case "&pgmdesc":
                        case "&time":
                        case "&page":
                        case "&line":
                        case "&output":
                            _lstVarUsada.Add(_var);
                            break;

                        default:
                            _lstVarNOUsada.Add(_var);
                            break;
                    }
                }
            }




            foreach (Variable _v in _lstVarUsada)
            {
                bool bComment = false;
                bool bNoComment = false;
                using (StringReader _strRead = new StringReader(_totalCode))
                {
                    while (true)
                    {
                        string _linea = _strRead.ReadLine();
                        if (_linea != null)
                        {
                            if (_linea.Contains(_v.Name2))
                            {
                                if (_linea.StartsWith("//"))
                                {
                                    bComment = true;
                                }
                                else
                                {
                                    bNoComment = true;
                                }
                            }
                            if (bComment && bNoComment)
                            {
                                break;
                            }

                        }
                        else
                        {
                            break;
                        }
                    }
                }

                if (bComment && !bNoComment)
                {
                    _lstVarNOUsada.Add(_v);
                }

            }


            //Ahora cargamos todaslas variables no utilizdas
            List<Coincidencia> _coincidencias = new List<Coincidencia>();
            foreach (Variable _v in _lstVarNOUsada)
            {
                Coincidencia _c = new Coincidencia();
                _c.Flag = "DataRowInutilizada";
                _c.RutaImg = "\\Flag_None.png";
                _c.NombreObj = GXLoadRules._Objeto.Name;
                _c.Linea = String.Format("&{0}", _v.Name);
                _coincidencias.Add(_c);
            }
            _Regla.ListaConcidencias = _coincidencias;


        }


        public static void ValVarNoUse2(GXValRegla _Regla)
        {

        }
        public static void ValDefinedBy(GXValRegla _Regla)
        {

        }

        public static void ValErrorWhere(GXValRegla _Regla)
        {

        }

        public static void ValDocument(GXValRegla _Regla)
        {

        }

        public static void ValErrorCALL(GXValRegla _Regla)
        {

        }

        public static void ValWordRest(GXValRegla _Regla)
        {

        }


    }
}
