﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gxViewer.GxValidador
{
    public class HardCode
    {
        private static List<string> _PalabrasReservadas;
        private static List<GXValRegla> _Reglas;


        public static List<string> PalabrasReservadas 
        { 
            get {
                if (_PalabrasReservadas==null)
                {
                    HardCode.CargarPalabrasReservadas();
                }
                return _PalabrasReservadas;
            }
            set { _PalabrasReservadas = value; } 
        }

        public static List<GXValRegla> Reglas
        {
            get
            {
                if (_Reglas == null)
                {
                    HardCode.CargarReglas();
                }
                return _Reglas;
            }
            set { _Reglas = value; }
        }

        private static void CargarPalabrasReservadas()
        {
            _PalabrasReservadas = new List<string>();
            _PalabrasReservadas.Add("WIESE");
            _PalabrasReservadas.Add("BANCO");
            _PalabrasReservadas.Add("S/.");
            _PalabrasReservadas.Add("USD");

        }

        private static void CargarReglas()
        {
            _Reglas = new List<GXValRegla>();
            _Reglas.Add(new GXValRegla("Constantes en Duro", "ValHardCode", 0));
            _Reglas.Add(new GXValRegla("Advertencias", "ValWarning", 0));
            _Reglas.Add(new GXValRegla("Posibles variables no usadas", "ValVarNoUse2", 0));
            _Reglas.Add(new GXValRegla("Variables no Utilizadas", "ValVarNoUse", 0));
            _Reglas.Add(new GXValRegla("For Each sin Defined by", "ValDefinedBy", 1));
            _Reglas.Add(new GXValRegla("Errores en Where de For Each", "ValErrorWhere", 2));
            _Reglas.Add(new GXValRegla("Documentacion", "ValDocument", 10));
            _Reglas.Add(new GXValRegla("Errores en llamadas CALL", "ValErrorCALL", 1));
            _Reglas.Add(new GXValRegla("Palabras restringidas", "ValWordRest", 5));

        }



    }
}
