using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace gxViewer
{
    public partial class frmMain : Form
    {
        private List<FilesGXOpen> _FilesGXOpen = new List<FilesGXOpen>();
        private Point _imageLocation = new Point(15, 5);
        private Point _imgHitArea = new Point(13, 2);
        private bool _HaveArgs = false;
        private string[] _Arguments;

        public frmMain()
        {
            InitializeComponent();
            //this.tabContents.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
        }

        public frmMain(string[] args)
        {
            InitializeComponent();

            _HaveArgs = true;
            _Arguments = args;
        }


        #region Subrutinas a nivel de Formularios
        private void SetTitle()
        {
            string _titulo = String.Format("GX Viewer ({2})   |   {0}\\{1}", Environment.UserDomainName, Environment.UserName, String.Format("{0}", Application.ProductVersion)  );
            this.Text = _titulo;
        }
        
        private void OpenFileGX()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Abrir archivo Distribuido de Genexus";
            ofd.Filter = FilesGX.GetFillesPrmitid(); //"Archivos XML (*.xml)|*.xml|Archivos XPW (*.xpw)|*.xpw";
            ofd.FilterIndex = 0;
            if (ofd.ShowDialog(this) == DialogResult.OK)
            {
                FileInfo _info = new FileInfo(ofd.FileName);
                OpenFileOK(_info);
            }
            ofd.Dispose();
        }

        private void OpenFileOK(FileInfo _info)
        {
            //txtPath.Text = _info.FullName;
            string _xmlstr = String.Empty;

            switch(_info.Extension.ToUpper())
            {
                case ".XPW" :
                    XPWREADERLib.XPWtoXMLClass _xpw = new XPWREADERLib.XPWtoXMLClass();
                    string _newxmlfilename = String.Format("{0}\\temp.xml", Application.StartupPath);
                    _xpw.ConvertToXML(_info.FullName, _newxmlfilename);
                    //_xmlstr = _xpw.GetXML(_info.FullName);
                    _xpw = null;
                    FileInfo _infotmp = new FileInfo(_newxmlfilename);
                    _xmlstr = System.IO.File.ReadAllText(_infotmp.FullName, Encoding.Default);
                    _infotmp.Delete();
                    break;
                
                case ".XPZ":
                    List<string> _files = ZipGX.ExtraerArchivos(_info.FullName);
                    foreach (string _sfile in _files)
                    {
                        _xmlstr = System.IO.File.ReadAllText(_sfile, Encoding.Default);
                    }
                    break;

                case ".XML" :
                    _xmlstr = System.IO.File.ReadAllText(_info.FullName, Encoding.Default);
                    break;

                case ".TXT":
                    try
                    {
                        _xmlstr = System.IO.File.ReadAllText(_info.FullName, Encoding.Default);
                        XmlDocument _xmltmp =  GxXML.GetDocument2(_xmlstr);
                        if (_xmltmp == null)
                        {
                            MessageBox.Show("El archivo no es compatible con GXViewer");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                    break;

                default:
                    MessageBox.Show("Tipo de Archivo no esta permitido");
                    return;
            }


            //SI CARGO BIEN EL ARCHIVO GX, entonces AGREGO A LA LISTA DE OBJETOS ABIERTOS
            FilesGXOpen _gxFile = new FilesGXOpen();
            _gxFile.Name = _info.Name;
            _gxFile.Path = _info.FullName;
            _gxFile.XMLText = _xmlstr;

            _gxFile.Objetos2 = this.GetObjectsByXML(_xmlstr); //new List<gxViewer.GxObject.GXObj>() ;

            _FilesGXOpen.Add(_gxFile);


            ReloadTreeview();


        }

        private List<object> GetObjectsByXML(string strXML)
        {
            //List<gxViewer.GxObject.GXObj> _ret = new List<gxViewer.GxObject.GXObj>();
            List<object> _ret = new List<object>();

            XmlDocument _xmlMain = GxXML.GetDocument2(strXML);
            XmlNodeList _xmlnodes = GxXML.ReadElements(_xmlMain, "GXObject");
            XmlNodeList _xmlnodesKNW = GxXML.ReadElements(_xmlMain, "KMW");

            //Recupero el Modelo correspondiente al archivo Distribuido
            GxObject.KMW _kmv = new gxViewer.GxObject.KMW();
            foreach (XmlNode _node01 in _xmlnodesKNW)
            {
                if (_node01 != null)
                {
                    _kmv = GxXML.XMLNodeToObject<GxObject.KMW>(_node01);
                }
            }

            foreach (XmlNode _xobj in _xmlnodes)
            {
                XmlNode _node = _xobj.FirstChild;
                if(_node!=null)
                {
                    Console.WriteLine(_node.Name);
                    if (FilesGX.ObjectIsValid(_node.Name))  //(_node.Name == "WorkPanel" || _node.Name == "Procedure" || _node.Name == "Transaction" || _node.Name == "DataView")
                    {
                        object _obj = GxXML.XMLNodeToObject(_node);

                        GxObject.GXObj _gxobj = _obj as GxObject.GXObj;
                        Console.WriteLine(_gxobj.Info.Name);

                        //-->Obtenemos las variables
                        if (_gxobj != null)
                        {
                            //List<GxObject.Variable> _vars = new List<GxObject.Variable>();
                            Dictionary<string, GxObject.Variable> _vars = new Dictionary<string, gxViewer.GxObject.Variable>();
                            Dictionary<string, GxObject.GXAtt> _attrs = new Dictionary<string, gxViewer.GxObject.GXAtt>();
                            //List<GxObject.GXAtt> _attrs = new List<GxObject.GXAtt>();
                            

                            //GxObject.Variable

                            XmlDocument _docXml = GxXML.GetDocument2(_node.OuterXml);
                            XmlNodeList _xmlvariables = GxXML.ReadElements(_docXml, "Variable");

                            

                            foreach (XmlNode _v in _xmlvariables)
                            {
                                GxObject.Variable _var = GxXML.XMLNodeToObject<GxObject.Variable>(_v);
                                if (!_vars.ContainsKey(_var.Name))
                                {
                                    _vars.Add(_var.Name, _var);    
                                }
                            }
                            _gxobj.Variables = new GxObject.Variable[_vars.Count];
                            _vars.Values.CopyTo(_gxobj.Variables, 0);
                            _gxobj.GXVariables = _vars;

                            //GxObject.Attributes
                            XmlNode _nodeAttrs = _node.ParentNode.NextSibling;
                            if (_nodeAttrs != null)
                            {
                                if (_nodeAttrs.Name == "Attributes")
                                {
                                    _docXml = GxXML.GetDocument2(_nodeAttrs.OuterXml);
                                    XmlNodeList _xmlattrs = GxXML.ReadElements(_docXml, "GXAtt");
                                    foreach (XmlNode _atr in _xmlattrs)
                                    {
                                        GxObject.GXAtt _a = GxXML.XMLNodeToObject<GxObject.GXAtt>(_atr);
                                        _attrs.Add(_a.Name, _a);
                                    }
                                    _gxobj.GXAtts = new GxObject.GXAtt[_attrs.Count];
                                    _attrs.Values.CopyTo(_gxobj.GXAtts, 0);
                                    _gxobj.GXAtributos = _attrs;
                                }
                            }

                            //Puede ser que no hayan atributos por version anterior de Genexus
                            if (_gxobj.GXAtts == null)
                            {
                                bool _batrib = false;
                                
                                XmlNode _nAttr = _node.ParentNode.NextSibling;
                                if (_nAttr != null)
                                {
                                    if (_nAttr.Name == "GXAtt") { _batrib = true; } //Inicia Carga de Atributos

                                    while (_batrib)
                                    {
                                        GxObject.GXAtt _a = GxXML.XMLNodeToObject<GxObject.GXAtt>(_nAttr);
                                        _attrs.Add(_a.Name, _a);

                                        _nAttr = _nAttr.NextSibling;
                                        if (_nAttr != null)
                                        {
                                            if (_nAttr.Name == "GXAtt") { _batrib = true; } else { _batrib = false; }
                                        }
                                        else
                                        {
                                            _batrib = false;
                                        }
                                        

                                    }

                                    if (_attrs.Count > 0)
                                    {
                                        _gxobj.GXAtts = new GxObject.GXAtt[_attrs.Count];
                                        _attrs.Values.CopyTo(_gxobj.GXAtts, 0);
                                        _gxobj.GXAtributos = _attrs;
                                    }
                                }
                            }

                            //Obtenemos Propiedades del Objeto
                            Dictionary<string, GxObject.Property> _props = new Dictionary<string, gxViewer.GxObject.Property>();
                             _docXml = GxXML.GetDocument2(_node.OuterXml);
                            XmlNodeList _xmlproperties = GxXML.ReadElements(_docXml, "Property");

                            foreach (XmlNode _p in _xmlproperties)
                            {

                                if (_p.ParentNode.Name == _gxobj.Tipo)
                                {
                                    GxObject.Property _prp = GxXML.XMLNodeToObject<GxObject.Property>(_p);
                                    _props.Add(_prp.Name, _prp);
                                    //Console.WriteLine(_prp.Name + "-->" + _p.ParentNode.Name);
                                } 

                            }
                            _gxobj.Propiedades = _props;

                        }

                        _gxobj.KMW = _kmv;
                        _gxobj.XMLObj = _node.OuterXml;
                        _ret.Add(_gxobj);

                    }
                }
            }

            return _ret;

        }

        private void ReloadTreeview()
        {
            tvObjetos.ImageList = imageList1;
            tvObjetos.Nodes.Clear();
            foreach (FilesGXOpen _gxf in _FilesGXOpen)
            {
                TreeNode _tvMain = tvObjetos.Nodes.Add(_gxf.Name);
                _tvMain.ToolTipText = _gxf.Path;
                _tvMain.ImageIndex = imageList1.Images.IndexOfKey("folder");
                _tvMain.SelectedImageIndex = _tvMain.ImageIndex;
                //_tvMain.Tag = _gxf.pa;

                foreach (GxObject.GXObj _obj in _gxf.Objetos2)
                {
                    string _strTextTreeview = _obj.Info.Name;
                    if (_obj.Tipo == "Procedure" || _obj.Tipo == "WorkPanel" || _obj.Tipo == "Report")
                    {
                        _strTextTreeview = string.Format("{0}{1}", _obj.Tipo.Substring(0, 1), _obj.Info.Name);
                    }

                    TreeNode _tvHijo = _tvMain.Nodes.Add(_strTextTreeview);
                    _tvHijo.ToolTipText = _obj.LastUpdate.ToString();
                    _tvHijo.Name = _obj.Tipo.Substring(0,1) + _obj.Info.Name;
                    _tvHijo.Tag = _obj;
                    _tvHijo.ImageIndex = imageList1.Images.IndexOfKey(_obj.Tipo.ToLower());
                    _tvHijo.SelectedImageIndex = _tvHijo.ImageIndex;
                }
 
            }

        }

        private void AddTabMain( Control c, string _KeyImage )
        {
            if (!tabContents.TabPages.ContainsKey(String.Format("tb{0}", c.Name)))
            {
                c.Dock = DockStyle.Fill;
                TabPage _newtab = new TabPage(c.Text);
                _newtab.Name = String.Format("tb{0}", c.Name );
                _newtab.ImageIndex = imageList1.Images.IndexOfKey(_KeyImage);
                //_newtab.ImageIndex = 0;
                

                _newtab.Controls.Add(c);
                tabContents.TabPages.Add(_newtab);
                tabContents.SelectedTab = _newtab;
            }
            else
            {
                int _idx = tabContents.TabPages.IndexOfKey(String.Format("tb{0}", c.Name));
                tabContents.SelectedTab = tabContents.TabPages[_idx];
            }
        }


        #endregion

        #region Eventos

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.SetTitle();

            if (_HaveArgs)
            {

                //_Arguments = args;
            }
        }


        

        private void tsbOpen_Click(object sender, EventArgs e)
        {
            this.OpenFileGX();
        }

        

        private void tvObjetos_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Tag != null) //Esto indica que se tiene un objeto asociado
            {
                GxEditor _gxObject = new GxEditor();
                _gxObject.Name = e.Node.Name;
                _gxObject.Text = e.Node.Text;
                _gxObject.objetoGX = e.Node.Tag;
                string _keyimage=String.Empty;
                if(_gxObject.objetoGX!=null)
                {
                    _keyimage = ((GxObject.GXObj)_gxObject.objetoGX).Tipo;
                }
                this.AddTabMain(_gxObject, _keyimage.ToLower());
            }



        }

        #endregion

        private void tsbAbout_Click(object sender, EventArgs e)
        {
            frmAboutBox _frm = new frmAboutBox();
            _frm.ShowDialog(this);
        }

        private void txtFindTreeview_TextChanged(object sender, EventArgs e)
        {
            if (_FilesGXOpen.Count > 0)
            {
                this.BuscarTreeview();
            }
        }


        private void BuscarTreeview()
        {
            string _strABuscar = txtFindTreeview.Text.ToUpper();
            int _len = _strABuscar.Length;
            int _indexOf = 0;

            if(txtFindTreeview.Text.Length <= 0)
            {
                return;
            }

            foreach (TreeNode t1 in tvObjetos.Nodes)
            {
                if (t1.Text.Length >= _len)
                {
                    if (t1.Text.Substring(0, _len).ToUpper() == _strABuscar)
                    {
                        _indexOf = t1.Index;
                        tvObjetos.SelectedNode = t1;
                        break;
                    }
                }

                foreach (TreeNode t2 in t1.Nodes)
                {
                    if (t2.Text.Length >= _len)
                    {
                        if (t2.Text.Substring(0, _len).ToUpper() == _strABuscar)
                        {
                            tvObjetos.SelectedNode = t2;
                            _indexOf = t2.Index;
                            break;
                        }
                    }
                }
            }


            
 
        }

        private void frmMain_DragDrop(object sender, DragEventArgs e)
        {
            // Comprobar si el tipo de datos es el que queremos
            if (e.Data.GetDataPresent("FileName", false))
            {
                string[] _FilesDrop = (string[])(e.Data.GetData("FileDrop", false));
                foreach (string sfile in _FilesDrop)
                {
                    FileInfo _info = new FileInfo(sfile);
                    OpenFileOK(_info);
                }
            }
        }

        private void frmMain_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void tvObjetos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (tvObjetos.Nodes.Count == 0) { return; }
                if (MessageBox.Show( String.Format("Estas seguro de Eliminar el Archivo cargado {0}", tvObjetos.SelectedNode.Text),this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    try
                    {
                        TreeNode _tvDel = tvObjetos.SelectedNode;

                        foreach (FilesGXOpen _gxf in _FilesGXOpen)
                        {
                            if (_gxf.Name == _tvDel.Text)
                            {
                                _FilesGXOpen.Remove(_gxf);
                                break;
                            }
                        }

                        
                        ReloadTreeview();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show( String.Format("Seleccione un nodo Superior \n{0}", ex.Message), this.Text,  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        
                    }
                    
                    
                }

                
            }
        }

        private void abrirArchivoGXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.OpenFileGX();
        }

        private void nuevoArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GxEditor _gxObject = new GxEditor();
            _gxObject.Name = "NewObj-" + DateTime.Now.ToString("yyyyMMddhhmmss");
            _gxObject.Text = _gxObject.Name;
            _gxObject.objetoGX = null;
            string _keyimage = "procedure";
            this.AddTabMain(_gxObject, _keyimage.ToLower());
        }

        public void OpenFileForArguments(string _filename)
        {
            try
            {
                FileInfo _info = new FileInfo(_filename);
                OpenFileOK(_info);
                tvObjetos.ExpandAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            

        }


        private void convertirHtmlDLAEnXPWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Abrir archivo HTML DLA";
            ofd.Filter = "Archivos HTML (*.htm)|*.htm|Archivos HTML (*.html)|*.html";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog(this) == DialogResult.OK)
            {
                FileInfo _info = new FileInfo(ofd.FileName);
                string _type =String.Empty;
                GxObject.GXObj _gxObj = HTMLtoGxXML.ConvertXML(_info.FullName);

                FilesGXOpen _gxFile = new FilesGXOpen();
                _gxFile.Name = _info.Name;
                _gxFile.Path = _info.FullName;

                List<object> _ret = new List<object>();
                _ret.Add(_gxObj);
                
                _gxFile.Objetos2 = _ret;

                _FilesGXOpen.Add(_gxFile);


                ReloadTreeview();



                _info = null;
            }
            ofd.Dispose();


            
        }

        private void convertirXPWEnXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Title = "Abrir archivo Distribuido de Genexus";
                ofd.Filter = FilesGX.GetFillesPrmitid("xpw,xpz");
                ofd.FilterIndex = 0;
                if (ofd.ShowDialog(this) == DialogResult.OK)
                {
                    FileInfo _info = new FileInfo(ofd.FileName);
                    string _xmlstr = String.Empty;

                    switch (_info.Extension.ToUpper())
                    {
                        case ".XPW":
                            XPWREADERLib.XPWtoXMLClass _xpw = new XPWREADERLib.XPWtoXMLClass();
                            string _newxmlfilename = String.Format("{0}\\temp.xml", Application.StartupPath);
                            _xpw.ConvertToXML(_info.FullName, _newxmlfilename);
                            _xpw = null;
                            FileInfo _infotmp = new FileInfo(_newxmlfilename);
                            _xmlstr = System.IO.File.ReadAllText(_infotmp.FullName, Encoding.Default);

                            _infotmp.Delete();
                            break;

                        case ".XPZ":
                            List<string> _files = ZipGX.ExtraerArchivos(_info.FullName);
                            foreach (string _sfile in _files)
                            {
                                _xmlstr = System.IO.File.ReadAllText(_sfile, Encoding.Default);
                            }
                            break;

                        default:
                            MessageBox.Show("Tipo de Archivo no esta permitido");
                            return;
                    }

                    if (_xmlstr != String.Empty)
                    {

                        frmViewXML _fXML = new frmViewXML();
                        string _titulo = String.Format("{0})", _info.Name);
                        _fXML.SetTitle(_titulo);

                        System.Xml.Linq.XDocument _doc = System.Xml.Linq.XDocument.Parse(_xmlstr);
                        _xmlstr = _doc.ToString();

                        _doc = null;
                        _fXML.LoadString(_xmlstr);
                        _fXML.Show(this);
                    }


                }
                ofd.Dispose();
            }
            catch (Exception ex )
            {
                MessageBox.Show(ex.Message, "Comunicarse con John Aima", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }

            

        }

        private void buscarObjetosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            testControls _frm = new testControls();
            _frm.ShowDialog(this);
            //MessageBox.Show("Esta opci�n no esta implementada en esta versi�n \n Comuniquese con el administrador del aplicativo C.A.R.");
        }

        private void obtenerXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Esta opci�n no esta implementada en esta versi�n \n Comuniquese con el administrador del aplicativo C.A.R.");
        }

        private void TSMIguardarArchivosAbiertos_Click(object sender, EventArgs e)
        {

            FolderBrowserDialog ofd = new FolderBrowserDialog();
            ofd.SelectedPath = Application.StartupPath;
            if (ofd.ShowDialog(this) == DialogResult.OK)
            {
                foreach (FilesGXOpen _gxf in _FilesGXOpen)
                {
                    
                    FileInfo _info = new FileInfo(_gxf.Path);

                    //TreeNode _tvMain = tvObjetos.Nodes.Add(_gxf.Name);
                    //_tvMain.ToolTipText = _gxf.Path;
                    //_tvMain.ImageIndex = imageList1.Images.IndexOfKey("folder");
                    //_tvMain.SelectedImageIndex = _tvMain.ImageIndex;
                    ////_tvMain.Tag = _gxf.pa;

                    //foreach (GxObject.GXObj _obj in _gxf.Objetos2)
                    //{
                    //    string _strTextTreeview = _obj.Info.Name;
                    //    if (_obj.Tipo == "Procedure" || _obj.Tipo == "WorkPanel" || _obj.Tipo == "Report")
                    //    {
                    //        _strTextTreeview = string.Format("{0}{1}", _obj.Tipo.Substring(0, 1), _obj.Info.Name);
                    //    }

                    //    TreeNode _tvHijo = _tvMain.Nodes.Add(_strTextTreeview);
                    //    _tvHijo.ToolTipText = _obj.LastUpdate.ToString();
                    //    _tvHijo.Name = _obj.Tipo.Substring(0, 1) + _obj.Info.Name;
                    //    _tvHijo.Tag = _obj;
                    //    _tvHijo.ImageIndex = imageList1.Images.IndexOfKey(_obj.Tipo.ToLower());
                    //    _tvHijo.SelectedImageIndex = _tvHijo.ImageIndex;
                    //}

                }
            }
            ofd.Dispose();

        }

        private void newEditorHighlighToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmViewXML _fXML = new frmViewXML();
            string _titulo = String.Format("{0})", "Nuevo Archivo");
            _fXML.SetTitle(_titulo);
            _fXML.Show(this);
        }


    }
}