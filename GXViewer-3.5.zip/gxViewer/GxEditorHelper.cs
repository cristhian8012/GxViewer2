using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using gxViewer.GxObject;
using System.Xml;

namespace gxViewer
{
    public class GxEditorHelper
    {
        public static string GetColorInfo(string _Color)
        {
            string _retCodeHTMLColor = "#00FF00"; //Verde por Default
            switch (_Color)
            {
                case "Black": _retCodeHTMLColor = "#000000"; break;
                case "Maroon": _retCodeHTMLColor = "#800000"; break;
                case "Green": _retCodeHTMLColor = "#008000"; break;
                case "Olive": _retCodeHTMLColor = "#808000"; break;
                case "Navy": _retCodeHTMLColor = "#000080"; break;
                case "Purple": _retCodeHTMLColor = "#800080"; break;
                case "Teal": _retCodeHTMLColor = "#008080"; break;
                case "Gray": _retCodeHTMLColor = "#808080"; break;
                case "Silver": _retCodeHTMLColor = "#C0C0C0"; break;
                case "Red": _retCodeHTMLColor = "#FF0000"; break;
                case "Lime": _retCodeHTMLColor = "#00FF00"; break;
                case "Yellow": _retCodeHTMLColor = "#FF0000"; break;
                case "Blue": _retCodeHTMLColor = "#0000FF"; break;
                case "Fuchsia": _retCodeHTMLColor = "#FF0000"; break;
                case "Aqua": _retCodeHTMLColor = "#FF00FF"; break;
                case "White": _retCodeHTMLColor = "#FFFFFF"; break;   
            }
            return _retCodeHTMLColor;
        }


        public static class Transaction
        {
            public static string GetHTMLStruct(GxObject.Transaction _trn, ImageList imageList1)
            {

                string _fileimg = String.Format("{0}\\img", Application.StartupPath);
                if (!System.IO.Directory.Exists(_fileimg))
                {
                    System.IO.Directory.CreateDirectory(_fileimg);
                    _fileimg = _fileimg + "\\llave.png";

                    imageList1.Images["key"].Save(_fileimg);
                }
                else
                { _fileimg = _fileimg + "\\llave.png"; }


                StringBuilder _htmlStruct = new StringBuilder("<html><body><table border=1>");
                if (_trn.Structure.Source != null)
                {
                    string[] _Structure = _trn.Structure.Source.Split("\n".ToCharArray());

                    _htmlStruct.AppendLine("<tr><td>&nbsp;</td><td>Structure</td><td>Type</td> <td>Description</td> <td>Formula</td>  </tr>\n");

                    foreach (string _field in _Structure)
                    {
                        int _isKey = _field.IndexOf("*");
                        string _fieldName = _field.Replace("*", "").Replace("\r", "").Replace("(", "").Replace(")", "").Trim();

                        if (_fieldName != String.Empty)
                        {

                            GXAtt _atrib = new GXAtt();
                            if ( _trn.GXAtts != null)
                            {
                                foreach (GXAtt _at in _trn.GXAtts)
                                {
                                    if (_at.Name.ToLower() == _fieldName.ToLower())
                                    {
                                        _atrib = _at;
                                        break;
                                    }
                                }
                            }

                            if (_isKey > 0)
                            {
                                _htmlStruct.AppendFormat("<tr><td><img src='{4}'></td><td>{0}</td>  <td>{1}</td>  <td>{2}</td>  <td>{3}</td> </tr>\n", _fieldName, _atrib.TipoCompleto, (_atrib.Title == String.Empty ? "&nbsp;" : _atrib.Title), "&nbsp;", _fileimg);
                            }
                            else
                            {
                                _htmlStruct.AppendFormat("<tr><td>&nbsp;</td><td>{0}</td>  <td>{1}</td>  <td>{2}</td>  <td>{3}</td>  </tr>\n", _fieldName, _atrib.TipoCompleto, (_atrib.Title == String.Empty ? "&nbsp;" : _atrib.Title), "&nbsp;");
                            }
                        }


                    }
                    
                }
                _htmlStruct.AppendLine("</table></body></html>");

                return _htmlStruct.ToString();
 
            }


        }

        public static class WorkPanel
        {

            public static void PrepareLayoutXML(GxObject.WorkPanel _wpn)
            {
                XmlDocument _docXml = GxXML.GetDocument2(_wpn.XMLObj);
                XmlNodeList _xmlForms = GxXML.ReadElements(_docXml, "Form");
                foreach (XmlNode _f in _xmlForms)
                {
                    GxObject.Form _form = GxXML.XMLNodeToObject<GxObject.Form>(_f);
                    _wpn.Form = _form;
                }
 
            }

            public static string GetHTMLDesign(GxObject.WorkPanel _wpn, ImageList imageList1)
            {

                StringBuilder _htmlDesign = new StringBuilder("<html><body>");
                
                //STATIC TEXTS
                if (_wpn.Form != null)
                {
                    int _wwidth = (_wpn.Form.Block.Frame.right - _wpn.Form.Block.Frame.left);
                    int _wheight = (_wpn.Form.Block.Frame.bottom - _wpn.Form.Block.Frame.top);
                    int _wleft = _wpn.Form.Block.Frame.left;
                    int _wtop = _wpn.Form.Block.Frame.top;
                    string _backcolor  = GxEditorHelper.GetColorInfo("Black");
                    string _forecolor  = GxEditorHelper.GetColorInfo("Lime");

                    _htmlDesign.AppendLine(String.Format("<div style='position:absolute; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; background-color:{4}; color:{5}'><br><br>", _wleft, _wtop, _wwidth, _wheight, _backcolor, _forecolor));

                    foreach (Text _txt in _wpn.Form.Block.Texts)
                    {
                        string _stylefont = String.Empty;
                        if (_txt.Font != null)
                        {
                            _stylefont = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2};", _txt.Font.Name, (_txt.Font.Size == 0 ? 10 : _txt.Font.Size) + 1, (_txt.Font.Underline == "Y" ? "underline" : "none"));
                        }
                        if (_txt.ColorInfo != null)
                        {
                            _stylefont = String.Format("{0} color:{1};", _stylefont, GxEditorHelper.GetColorInfo(_txt.ColorInfo.Foreground));
                        }

                        string _divText = String.Format("<div style='position:absolute; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; {5}'>{4}</div>", _txt.left, _txt.top, (_txt.right - _txt.left), (_txt.bottom - _txt.top), ( _txt.Texto == null ? "&nbsp;" : _txt.Texto.Replace(" ", "&nbsp;")), _stylefont);
                        _htmlDesign.AppendLine(_divText);
                    }


                    //FIELDS
                    foreach (Edit _edit in _wpn.Form.Block.Edits)
                    {
                        string _stylefont2 = String.Empty;
                        if (_edit.Font != null)
                        {
                            _stylefont2 = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2}", _edit.Font.Name, (_edit.Font.Size == 0 ? 10 : _edit.Font.Size) + 1, (_edit.Font.Underline == "Y" ? "underline" : "none"));
                        }
                        if (_edit.ColorInfo != null)
                        {
                            _stylefont2 = String.Format("{0} color:{1};", _stylefont2, GxEditorHelper.GetColorInfo(_edit.ColorInfo.Foreground));
                        }

                        string _divEdit = String.Format("<div style='position:absolute; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; border:0px solid #eee24; overflow:hidden; {5}' title='{4}'>&{4}</div>", _edit.left, _edit.top, (_edit.right - _edit.left), (_edit.bottom - _edit.top), _edit.Name, _stylefont2);
                        _htmlDesign.AppendLine(_divEdit);
                    }

                    //GRIDS
                    string _fontHeader = "<span style='font-family:Courier New; font-size:11px; color:#00FF00;'>{0}</span>";
                    string _fontRow = "<div style='font-family:Courier New; font-size:11px; text-decoration:underline; color:#00FF00; overflow:hidden; width:{1}px;' title='{2}'>{0}</div>"; ;

                    foreach (SubFile _sf in _wpn.Form.Block.Subfiles)
                    {
                        int _Heigth = (_sf.bottom - _sf.top);
                        int _Width = (_sf.right - _sf.left) - 30;
                        string _divSubFile = String.Format("<div style='position:absolute; font-size:9px;font-family:Courier New; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; overflow-y:visible; overflow-x:hidden; '>", _sf.left, _sf.top, _Width, _Heigth);
                        


                        string _Table = "<table cellpadding='0' cellspacing='1'  id='" + _sf.CtrlName + "' style='border:0px solid #999999;' width='90%'; >";
                        string _fieldsBlank = String.Empty;
                        _Table += "<theader>";
                        _Table += "<tr>";
                        foreach (Item _i in _sf.Items)
                        {
                            GxObject.Variable _var = _wpn.getVarByName(_i.Name);
                            
                            string _sTitulo = String.Format(_fontHeader, (_i.Title == null ? "&nbsp;" : _i.Title.Replace(" ", "&nbsp;"))) ;
                            string _sData = String.Empty;
                            if (_var != null)
                            {
                                _Table += String.Format("<td nowrap style='width:{0}px; border:0px solid #999999;'>", _i.Width) + _sTitulo + "</td>\n        ";
                                int _widthitem = (8 * _var.Length);
                                string wNameVar = _var.Name2 ;
                                int _diff = _widthitem - (_var.Name2.Length * 8);
                                if (_diff > 0) 
                                {
                                    wNameVar = wNameVar.PadRight((_diff / 8));
                                    wNameVar = wNameVar.Replace(" ", "&nbsp;");
                                }
                                _sData = String.Format(_fontRow, wNameVar, _widthitem, (_var.Title));

                                _fieldsBlank += "<td style='border:0px solid #999999;'>" + _sData + "</td>";
                            }
                            else
                            {
                                _Table += String.Format("<td nowrap style='width:{0}px; border:0px solid #999999;'>", _i.Width) + _sTitulo + "</td>\n        ";
                                _fieldsBlank += "<td style='border:0px solid #999999;'>&nbsp;</td>";
                            }
                        }
                        _Table += "</tr>";
                        _Table += "</theader>";


                        _Table += "<tbody>";
                        int _rowsInSF = (_Heigth / 21);
                        if (_rowsInSF != (_rowsInSF * 20)) { _rowsInSF++; }


                        if (_rowsInSF <= 0) { _rowsInSF = 7; }
                        for (int x = 1; x <= _rowsInSF; x++)
                        {
                            _Table += "<tr style='height:15px;'>";
                            _Table += _fieldsBlank;
                            _Table += "</tr>";
                        }
                        _Table += "</tbody>";

                        _Table += "<tfooter>";
                        _Table += "</tfooter>";



                        _Table += "</table>";

                        _divSubFile += _Table + "</div>";

                        _htmlDesign.AppendLine(_divSubFile);
                    }
                    //END GRID

                    _htmlDesign.AppendLine("</div>");
                }

                _htmlDesign.AppendLine("</body></html>");

                return _htmlDesign.ToString();

            }


        }

        public static class Procedure
        {

            public static void PrepareLayoutXML(GxObject.Procedure _prc)
            {
                XmlDocument _docXml = GxXML.GetDocument2(_prc.XMLObj);
                XmlNodeList _xmlvariables = GxXML.ReadElements(_docXml, "Layout");
                foreach (XmlNode _f in _xmlvariables)
                {
                    GxObject.Layout _form = GxXML.XMLNodeToObject<GxObject.Layout>(_f);
                    _prc.Layout = _form;
                }

            }

            public static string GetHTMLDesign(GxObject.Procedure _wpn, ImageList imageList1)
            {

                if (_wpn.Layout == null)
                {
                    return String.Empty;
                }
                if (_wpn.Layout.Blocks == null)
                {
                    return String.Empty;
                }


                StringBuilder _htmlDesign = new StringBuilder("<html><body><br><br>");
                //STATIC TEXTS
                foreach (Block _blk in _wpn.Layout.Blocks)
                {
                    PrintBlock _pblk = _blk.PrintBlock;

                    if (_pblk != null)
                    {

                        string _divLabelBLock = String.Format("<div style='position:absolute; font-size:10px;font-family:Arial; left:0px; top:{0}; display:block; '>{1}</div>", _pblk.top, _pblk.CtrlName);

                        StringBuilder _edits = new StringBuilder();

                        //FIELDS
                        if (_blk.Edits != null)
                        {
                            foreach (Text _text in _blk.Texts)
                            {
                                string _stylefont2 = String.Empty;
                                if (_text.Font != null)
                                {
                                    _stylefont2 = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2}", _text.Font.Name, (_text.Font.Size == 0 ? 10 : _text.Font.Size) + 1, (_text.Font.Underline == "Y" ? "underline" : "none"));
                                }
                                else
                                {
                                    _stylefont2 = "font-family:Courier New; font-size:10px;";
                                }

                                string _divEdit = String.Format("<div style='position:absolute; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; border:0px solid #eee24; {5}'>{4}</div>", _text.left, _text.top, (_text.right - _text.left), (_text.bottom - _text.top), _text.Texto, _stylefont2);
                                _edits.AppendLine(_divEdit);
                            }


                            foreach (Edit _edit in _blk.Edits)
                            {
                                string _stylefont2 = String.Empty;
                                if (_edit.Font != null)
                                {
                                    //Variable _v = _wpn.getVarByName(_edit.Name);
                                    string _tamanio = String.Empty;
                                    //if (_v != null)
                                    //{ 
                                    //    _tamanio = String.Format("width:{0}px;", _v.Length*10 );
                                    //}


                                    _stylefont2 = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2}; {3}", _edit.Font.Name, (_edit.Font.Size == 0 ? 10 : _edit.Font.Size) + 1, (_edit.Font.Underline == "Y" ? "underline" : "none"), _tamanio);
                                }
                                else
                                {
                                    _stylefont2 = "font-family:Courier New; font-size:10px;";
                                }



                                string _divEdit = String.Format("<div style='position:absolute;left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; border:0px solid #eee24; overflow:hidden; {5}' title='&{4}'>&{4}</div>", _edit.left, _edit.top, (_edit.right - _edit.left), (_edit.bottom - _edit.top), _edit.Name, _stylefont2);
                                _edits.AppendLine(_divEdit);
                            }


                        }
                        string _divPBLock = String.Format("<div style='position:absolute; border:1px solid; left:{0}; top:{1}; width:{2}px; height:{4}px; display:block;'>{3}</div>", _pblk.left, _pblk.top, (_pblk.right - _pblk.left), _edits.ToString(), (_pblk.bottom - _pblk.top));

                        _htmlDesign.AppendLine(_divLabelBLock);
                        _htmlDesign.AppendLine(_divPBLock);
                    }
                }




                _htmlDesign.AppendLine("</body></html>");

                return _htmlDesign.ToString();

            }


        }

        public static class Report
        {

            public static void PrepareLayoutXML(GxObject.Report _prc)
            {
                XmlDocument _docXml = GxXML.GetDocument2(_prc.XMLObj);
                XmlNodeList _xmlvariables = GxXML.ReadElements(_docXml, "Layout");
                foreach (XmlNode _f in _xmlvariables)
                {
                    GxObject.Layout _form = GxXML.XMLNodeToObject<GxObject.Layout>(_f);
                    _prc.Layout = _form;
                }

            }

            public static string GetHTMLDesign(GxObject.Report _wpn, ImageList imageList1)
            {

                StringBuilder _htmlDesign = new StringBuilder("<html><body><br><br>");


                //STATIC TEXTS
                foreach (Block _blk in _wpn.Layout.Blocks)
                {
                    PrintBlock _pblk = _blk.PrintBlock;

                    if (_pblk != null)
                    {

                        string _divLabelBLock = String.Format("<div style='position:absolute; font-size:10px;font-family:Arial; left:0px; top:{0}; display:block; '>{1}</div>", _pblk.top, _pblk.CtrlName);

                        StringBuilder _edits = new StringBuilder();

                        //FIELDS
                        if (_blk.Edits != null)
                        {
                            foreach (Text _text in _blk.Texts)
                            {
                                string _stylefont2 = String.Empty;
                                if (_text.Font != null)
                                {
                                    _stylefont2 = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2}", _text.Font.Name, (_text.Font.Size == 0 ? 10 : _text.Font.Size) + 1, (_text.Font.Underline == "Y" ? "underline" : "none"));
                                }
                                else
                                {
                                    _stylefont2 = "font-family:Courier New; font-size:10px;";
                                }

                                string _divEdit = String.Format("<div style='position:absolute; left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; border:0px solid #eee24; overflow:hidden; {5}'>{4}</div>", _text.left, _text.top, (_text.right - _text.left), (_text.bottom - _text.top), _text.Texto, _stylefont2);
                                _edits.AppendLine(_divEdit);
                            }


                            foreach (Edit _edit in _blk.Edits)
                            {
                                string _stylefont2 = String.Empty;
                                if (_edit.Font != null)
                                {
                                    _stylefont2 = String.Format("font-family:{0}; font-size:{1}px; text-decoration:{2}", _edit.Font.Name, (_edit.Font.Size == 0 ? 10 : _edit.Font.Size) + 1, (_edit.Font.Underline=="Y" ? "underline" : "none" ));
                                }
                                else
                                {
                                    _stylefont2 = "font-family:Courier New; font-size:10px;";
                                }

                                string _divEdit = String.Format("<div style='position:absolute;left:{0}; top:{1}; width:{2}px; height:{3}px; display:block; border:0px solid #eee24; {5}' title='&{4}'>&{4}</div>", _edit.left, _edit.top, (_edit.right - _edit.left), (_edit.bottom -_edit.top ), _edit.Name, _stylefont2);
                                _edits.AppendLine(_divEdit);
                            }


                        }
                        string _divPBLock = String.Format("<div style='position:absolute; border:1px solid; left:{0}; top:{1}; width:{2}px; height:{4}px; display:block;'>{3}</div>", _pblk.left, _pblk.top, (_pblk.right - _pblk.left), _edits.ToString(), (_pblk.bottom-_pblk.top));

                        _htmlDesign.AppendLine(_divLabelBLock);
                        _htmlDesign.AppendLine(_divPBLock);
                    }
                }




                _htmlDesign.AppendLine("</body></html>");

                return _htmlDesign.ToString();

            }


        }



    }
}
