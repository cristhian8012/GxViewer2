﻿namespace gxViewer
{
    partial class testControls
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gxModelExplorer1 = new gxViewer.GxModelExplorer();
            this.SuspendLayout();
            // 
            // gxModelExplorer1
            // 
            this.gxModelExplorer1.Location = new System.Drawing.Point(3, 3);
            this.gxModelExplorer1.Name = "gxModelExplorer1";
            this.gxModelExplorer1.Size = new System.Drawing.Size(647, 486);
            this.gxModelExplorer1.TabIndex = 0;
            // 
            // testControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 508);
            this.Controls.Add(this.gxModelExplorer1);
            this.Name = "testControls";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "testControls";
            this.Load += new System.EventHandler(this.testControls_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private GxModelExplorer gxModelExplorer1;

    }
}