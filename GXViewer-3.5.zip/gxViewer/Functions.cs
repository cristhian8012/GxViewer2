using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;
using System.Reflection;
using System.Reflection.Emit;

namespace gxViewer
{
    public static class Functions
    {
        public static T DirectCast<T>(object o) { return (T)o; }

        public static T Deserialize<T>(string filenamexml)
        {
            T _objret;
            System.Xml.Serialization.XmlSerializer _ser = new System.Xml.Serialization.XmlSerializer(typeof(T));
            StreamReader _strm = new StreamReader(filenamexml, Encoding.Default);
            _objret = (T)_ser.Deserialize(_strm);

            return _objret;
        }

        public static T DeserializeXML<T>(string xmlXchema)
        {

            string _strFileName = String.Format("{0}\\archivotmp.xml", System.AppDomain.CurrentDomain.BaseDirectory);
            FileInfo _finfo = new FileInfo(_strFileName);
            if (_finfo.Exists)
            { File.Delete(_finfo.FullName); }

            File.WriteAllText(_finfo.FullName, xmlXchema, Encoding.Default);

            System.Windows.Forms.Application.DoEvents();

            return Deserialize<T>(_finfo.FullName);
        }

        #region Converting ObjectArray to Datatable
        public static DataTable ConvertToDataTable(Object[] array)
        {
            DataTable dt =new DataTable();
            if (array != null)
            {
                PropertyInfo[] properties = array.GetType().GetElementType().GetProperties();
                dt = CreateDataTable(properties);
                if (array.Length != 0)
                {
                    foreach (object o in array)
                    {
                        FillData(properties, dt, o);
                    }
                }
            }
            return dt;
        }
        private static DataTable CreateDataTable(PropertyInfo[] properties)
        {
            DataTable dt = new DataTable();
            DataColumn dc = null;
            foreach (PropertyInfo pi in properties)
            {
                dc = new DataColumn();
                dc.ColumnName = pi.Name;
                dc.DataType = pi.PropertyType;
                dt.Columns.Add(dc);
            }
            return dt;
        }
        private static void FillData(PropertyInfo[] properties, DataTable dt, Object o)
        {
            DataRow dr = dt.NewRow();
            foreach (PropertyInfo pi in properties)
            {
                dr[pi.Name] = pi.GetValue(o, null);
            }
            dt.Rows.Add(dr);
        }
        #endregion
    }
}

