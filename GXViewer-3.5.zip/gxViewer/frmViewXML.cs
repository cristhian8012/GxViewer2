using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace gxViewer
{
    public partial class frmViewXML : Form
    {
        FileInfo _ftxT = null;


        public void SetTitle(string _Title)
        {
            this.Text = String.Format("Visor XML | {0}", _Title);
        }

        public void LoadString(string _strXML)
        {
            txtXML.Text = _strXML;
        }

        public frmViewXML(string _FileName)
        {
            _ftxT = new FileInfo(_FileName);
            InitializeComponent();
        }

        public frmViewXML()
        {
            InitializeComponent();
        }

        private void frmViewXML_Load(object sender, EventArgs e)
        {
            if (_ftxT!=null)
            {
                if (_ftxT.Exists)
                {
                    //string _AllTXT = System.IO.File.ReadAllText(_ftxT.FullName, Encoding.Default);
                    txtXML.OpenFile(_ftxT.FullName, Encoding.Default);
                }
            }
        }

        private void irAToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void verLaAyudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void acercaDeXCAREditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAboutBox _frm = new frmAboutBox();
            _frm.ShowDialog(this);
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmViewXML _xNewForm = new frmViewXML();
            _xNewForm.Show();
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Abrir archivo XML";
            ofd.Filter = FilesGX.GetFillesPrmitid("xml,xsd,xlt,xhtml,html,htm,txt"); 
            ofd.FilterIndex = 0;
            if (ofd.ShowDialog(this) == DialogResult.OK)
            {
                //txtXML.Clear();
                _ftxT = new FileInfo(ofd.FileName);
                StreamReader _read = new StreamReader(_ftxT.FullName, Encoding.Default);
                string _StringTXT = _read.ReadToEnd();
                _read.Dispose();
                _read = null;

                string _ext = _ftxT.Extension.ToLower();

                if (_ext.Contains("xml") || _ext.Contains("xsd") || _ext.Contains("xlt"))
                {
                    System.Xml.Linq.XDocument _doc = System.Xml.Linq.XDocument.Parse(_StringTXT);
                    _StringTXT = _doc.ToString();
                    _doc = null;
                }
                else
                {
                    if (_ext.Contains("htm"))
                    {
                        txtXML.Language = FastColoredTextBoxNS.Language.HTML;
                    }
                }

                this.Refresh();
                this.SetTitle(_ftxT.FullName);
                this.LoadString(_StringTXT);
                txtXML.IsChanged = false;
                txtXML.Refresh();
                
            }
            ofd.Dispose();



        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (_ftxT == null)
            {
                guardarComoToolStripMenuItem_Click(null, null);
                return;
            }
            else
            {
                _ftxT = new FileInfo(_ftxT.FullName);
            }

            if (_ftxT.Exists)
            {
                _ftxT.Delete();
                Application.DoEvents();
            }
            this.SaveFileTxt(_ftxT.FullName);

            
        }


        private void SaveFileTxt(string _FileName)
        {
            using (StreamWriter sw = new StreamWriter(_FileName, true, Encoding.Default))
            {
                IList<string> _TextQ = new List<string>();
                _TextQ = txtXML.Lines;
                foreach (string sline in _TextQ)
                {
                    sw.WriteLine(sline);
                }
                sw.Close();
                txtXML.IsChanged = false;
            }
        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog _sfd = new SaveFileDialog();
            _sfd.Filter = FilesGX.GetFillesPrmitid("xml,xsd,xlt,xhtml,html,htm,txt");
            _sfd.FilterIndex = 0;

            if (_sfd.ShowDialog(this)== DialogResult.OK)
            {
                _ftxT = new FileInfo(_sfd.FileName);

                if (_ftxT.Exists)
                {
                    
                    if (MessageBox.Show("El archivo ya existe, � Desea reemplazarlo ?",this.Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)== DialogResult.OK)
                    {
                        _ftxT.Delete();
                    }
                    Application.DoEvents();
                }
                this.SaveFileTxt(_ftxT.FullName);
            }

        }

        private void configurarPaginaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                txtXML.Print(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!txtXML.IsChanged)
            { this.Close(); }
            else
            {
                if (MessageBox.Show("�Esta seguro de cerrar sin guardar los cambios ?", this.Text, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    this.Close();
                }
            }
        }

        private void colapsarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtXML.CollapseAllFoldingBlocks();
            
        }

        private void colapsarSeleccionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtXML.CollapseBlock(txtXML.Selection.Start.iLine, txtXML.Selection.End.iLine);
        }

        private void xMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.XML);
        }

        private void hTMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.HTML);
        }

        private void genexusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.Genexus);
        }

        private void rPGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.Lua); //Falta RPG
        }

        private void javaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.JS);
        }

        private void cToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.CSharp);
        }

        private void vBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.VB);
        }

        private void pHPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.PHP);
        }

        private void sQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ChangeSyntaxHighLight(FastColoredTextBoxNS.Language.SQL);
        }

        private void ChangeSyntaxHighLight( FastColoredTextBoxNS.Language _lang)
        {
            FastColoredTextBoxNS.SyntaxHighlighter _syntax = new FastColoredTextBoxNS.SyntaxHighlighter();
            txtXML.Language = _lang;
            txtXML.ClearStylesBuffer();
            this.txtXML.OnSyntaxHighlight(new FastColoredTextBoxNS.TextChangedEventArgs(this.txtXML.Range));
            txtXML.Refresh();
        }


        private void buscarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtXML.ShowFindDialog();
        }

        private void irAToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtXML.ShowGoToDialog();
        }

        private void reemplazarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtXML.ShowReplaceDialog();
        }

        private void buscarSiguienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void seleccionarTodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtXML.SelectAll();
        }

        private void fechaYHoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtXML.InsertText( DateTime.Now.ToString("dd/MM/yyyy hh:m1:ss"));
        }

    }
}