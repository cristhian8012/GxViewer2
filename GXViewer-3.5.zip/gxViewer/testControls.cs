using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace gxViewer
{
    public partial class testControls : Form
    {
        public testControls()
        {
            InitializeComponent();
        }

        private void testControls_Load(object sender, EventArgs e)
        {

        }
    }
}