﻿using FileToStrBase64;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace gxViewer
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            frmMain f = new frmMain();

            ////Para pruebas
            //frmTestTransformXLST _fx = new frmTestTransformXLST();
            //Application.Run(_fx);
            //return;
            ////Fin pruebas

            foreach (string s in args)
            {
                f.OpenFileForArguments(s);
            }

            Application.Run(f);

        }
        /*
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            frmViewXML f = new frmViewXML();

            foreach (string s in args)
            {
                f = new frmViewXML(s);
            }

            Application.Run(f);

        }
        */
        //[STAThread]
        //static void Main(string[] args)
        //{
        //    Application.EnableVisualStyles();
        //    Application.SetCompatibleTextRenderingDefault(false);
        //    Application.Run(new frmMain(args));
        //}
    }
}